"use client"

import { useState, useEffect } from "react"
import { ScalpBotLogo } from "@/components/scalp-bot-logo"
import { BalanceChart } from "@/components/balance-chart"
import { RecentTrades } from "@/components/recent-trades"
import { ProfitSummary } from "@/components/profit-summary"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import {
  RefreshCw,
  Search,
  ArrowLeft,
  Clock,
  Calendar,
  Shield,
  History,
  User,
  Download,
  Upload,
  LogIn,
  UserPlus,
} from "lucide-react"
import { Input } from "@/components/ui/input"
import { useMediaQuery } from "@/hooks/use-media-query"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { WithdrawDialog } from "@/components/withdraw-dialog"
import { DepositDialog } from "@/components/deposit-dialog"
import { PasswordAuth } from "@/components/password-auth"
import { AdminPanel } from "@/components/admin-panel"
import { AdminLogin } from "@/components/admin-login"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { UserProfile } from "@/components/user-profile"
import { RegisterForm } from "@/components/register-form"

// Current date: May 20, 2025
const CURRENT_DATE = new Date(2025, 4, 20)

// Format date as YYYY-MM-DD
const formatDate = (date: Date) => {
  return date.toISOString().split("T")[0]
}

// Format date as Month DD, YYYY
const formatDisplayDate = (date: Date) => {
  return date.toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })
}

// Initial wallet data
const initialWalletData = {
  agon: {
    balance: 47521.88,
    winRate: 68.7,
    profitFactor: 2.14,
    drawdown: 7.2,
    dailyTrades: 12.4,
    percentChange: 13.15,
    lastUpdateRequest: null,
    dayCounter: 0,
    currentDate: CURRENT_DATE,
    lastUpdated: CURRENT_DATE,
  },
  nexhaip: {
    balance: 38945.88,
    winRate: 62.3,
    profitFactor: 1.89,
    drawdown: 9.5,
    dailyTrades: 8.7,
    percentChange: 8.42,
    lastUpdateRequest: null,
    dayCounter: 0,
    currentDate: CURRENT_DATE,
    lastUpdated: CURRENT_DATE,
  },
  cryptowhale: {
    balance: 156789.45,
    winRate: 71.2,
    profitFactor: 2.45,
    drawdown: 5.8,
    dailyTrades: 15.3,
    percentChange: 22.67,
    lastUpdateRequest: null,
    dayCounter: 0,
    currentDate: CURRENT_DATE,
    lastUpdated: CURRENT_DATE,
  },
  tradingmaster: {
    balance: 85432.67,
    winRate: 65.9,
    profitFactor: 2.01,
    drawdown: 8.3,
    dailyTrades: 10.5,
    percentChange: 16.24,
    lastUpdateRequest: null,
    dayCounter: 0,
    currentDate: CURRENT_DATE,
    lastUpdated: CURRENT_DATE,
  },
  selami: {
    balance: 22986.77,
    winRate: 59.8,
    profitFactor: 1.76,
    drawdown: 10.2,
    dailyTrades: 7.3,
    percentChange: 6.75,
    lastUpdateRequest: null,
    dayCounter: 0,
    currentDate: CURRENT_DATE,
    lastUpdated: CURRENT_DATE,
  },
  milazim: {
    balance: 52843.55,
    winRate: 64.2,
    profitFactor: 2.05,
    drawdown: 8.7,
    dailyTrades: 11.2,
    percentChange: 15.34,
    lastUpdateRequest: null,
    dayCounter: 0,
    currentDate: CURRENT_DATE,
    lastUpdated: CURRENT_DATE,
  },
}

// Function to get a random number within a range
const getRandomAmount = (min: number, max: number) => {
  return Math.floor(Math.random() * (max - min + 1)) + min
}

// Function to calculate profit/loss based on day counter
const calculateProfitLoss = (dayCounter: number) => {
  // Days 0, 1, 2: Profit around $300 with variation
  if (dayCounter % 5 === 0 || dayCounter % 5 === 1 || dayCounter % 5 === 2) {
    return getRandomAmount(250, 350)
  }
  // Days 3, 4: Loss around $300 with variation
  else {
    return -getRandomAmount(250, 350)
  }
}

// Function to generate a new trade
const generateNewTrade = (walletName: string, date: Date, isProfit: boolean) => {
  const pairs = ["BTC/USDT", "ETH/USDT", "SOL/USDT", "DOGE/USDT", "PEPE/USDT", "SHIB/USDT", "AVAX/USDT"]
  const randomPair = pairs[Math.floor(Math.random() * pairs.length)]
  const tradeType = Math.random() > 0.5 ? "long" : "short"
  const amount = getRandomAmount(5000, 15000)
  const profit = isProfit ? getRandomAmount(2, 8) : -getRandomAmount(2, 8)

  const hours = getRandomAmount(9, 21)
  const minutes = getRandomAmount(0, 59)
  const seconds = getRandomAmount(0, 59)

  return {
    id: Date.now(),
    pair: randomPair,
    type: tradeType,
    amount: amount,
    profit: profit,
    date: formatDate(date),
    time: `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`,
  }
}

// Status badge component
function StatusBadge({ status }: { status: string }) {
  const variants = {
    pending: "bg-yellow-100 text-yellow-800 border-yellow-200",
    processing: "bg-blue-100 text-blue-800 border-blue-200",
    completed: "bg-green-100 text-green-800 border-green-200",
    rejected: "bg-red-100 text-red-800 border-red-200",
  }

  return (
    <Badge className={`${variants[status]} font-medium`} variant="outline">
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </Badge>
  )
}

export default function Dashboard() {
  const [searchQuery, setSearchQuery] = useState("")
  const [currentWallet, setCurrentWallet] = useState("")
  const [walletInfo, setWalletInfo] = useState<any>(null)
  const [searchError, setSearchError] = useState("")
  const [walletData, setWalletData] = useState(initialWalletData)
  const [updateMessage, setUpdateMessage] = useState("")
  const [updateStatus, setUpdateStatus] = useState<"none" | "pending" | "updated">("none")
  const [newTrade, setNewTrade] = useState<any>(null)
  const isMobile = useMediaQuery("(max-width: 768px)")
  const [withdrawDialogOpen, setWithdrawDialogOpen] = useState(false)
  const [depositDialogOpen, setDepositDialogOpen] = useState(false)
  const [showPasswordAuth, setShowPasswordAuth] = useState(false)
  const [pendingWalletName, setPendingWalletName] = useState("")
  const [showAdminPanel, setShowAdminPanel] = useState(false)
  const [showAdminLogin, setShowAdminLogin] = useState(false)
  const [withdrawalNotification, setWithdrawalNotification] = useState<string | null>(null)
  const [depositNotification, setDepositNotification] = useState<string | null>(null)
  const [withdrawalHistory, setWithdrawalHistory] = useState<any[]>([])
  const [depositHistory, setDepositHistory] = useState<any[]>([])
  const [showWithdrawalHistory, setShowWithdrawalHistory] = useState(false)
  const [showUserProfile, setShowUserProfile] = useState(false)
  const [showRegisterForm, setShowRegisterForm] = useState(false)
  const [referralCode, setReferralCode] = useState("")

  // Check for updates every minute
  useEffect(() => {
    const interval = setInterval(() => {
      if (walletInfo && walletInfo.lastUpdateRequest) {
        const now = new Date().getTime()
        const lastRequest = walletInfo.lastUpdateRequest
        const hoursSinceRequest = (now - lastRequest) / (1000 * 60 * 60)

        // If 24 hours have passed since the last request
        if (hoursSinceRequest >= 24) {
          // Update the wallet data
          const updatedWalletData = { ...walletData }
          const wallet = updatedWalletData[currentWallet]

          // Calculate profit/loss based on day counter
          const profitLoss = calculateProfitLoss(wallet.dayCounter)
          const isProfit = profitLoss > 0

          // Update balance
          wallet.balance = Math.round((wallet.balance + profitLoss) * 100) / 100

          // Increment day counter
          wallet.dayCounter = (wallet.dayCounter + 1) % 5

          // Update date - add 1 day
          const newDate = new Date(wallet.currentDate)
          newDate.setDate(newDate.getDate() + 1)
          wallet.currentDate = newDate
          wallet.lastUpdated = newDate

          // Reset last update request
          wallet.lastUpdateRequest = null

          // Generate a new trade
          const newTradeData = generateNewTrade(currentWallet, newDate, isProfit)
          setNewTrade(newTradeData)

          // Update state
          setWalletData(updatedWalletData)
          setWalletInfo(wallet)
          setUpdateStatus("updated")
          setUpdateMessage(`Balance updated! ${profitLoss >= 0 ? "+" : ""}${profitLoss.toFixed(2)} USDT`)

          // Clear message after 5 seconds
          setTimeout(() => {
            setUpdateStatus("none")
            setUpdateMessage("")
          }, 5000)
        }
      }
    }, 60000) // Check every minute

    return () => clearInterval(interval)
  }, [walletInfo, currentWallet, walletData])

  // Check for URL parameters (for referral links)
  useEffect(() => {
    // In a real app, this would parse the URL for referral codes
    const urlParams = new URLSearchParams(window.location.search)
    const ref = urlParams.get("ref")

    if (ref) {
      setReferralCode(ref)
      setShowRegisterForm(true)
    }
  }, [])

  // Update the handleAdminAccess function
  const handleAdminAccess = () => {
    setShowAdminLogin(true)
  }

  // Add a new function for admin login success
  const handleAdminLoginSuccess = () => {
    setShowAdminLogin(false)
    setShowAdminPanel(true)
  }

  // Add a new function for admin login cancel
  const handleAdminLoginCancel = () => {
    setShowAdminLogin(false)
  }

  const handleSearch = () => {
    const normalizedQuery = searchQuery.toLowerCase().trim()
    if (walletData[normalizedQuery]) {
      setPendingWalletName(normalizedQuery)
      setShowPasswordAuth(true)
    } else {
      // Simplified error message
      setSearchError(`Wallet name isn't found or is missing. Check the name again.`)
    }
  }

  const handlePasswordSuccess = () => {
    setShowPasswordAuth(false)
    setCurrentWallet(pendingWalletName)
    setWalletInfo(walletData[pendingWalletName])
    setSearchError("")
    setUpdateStatus("none")
    setUpdateMessage("")
    setNewTrade(null)
    setPendingWalletName("")
    setWithdrawalHistory([]) // Reset withdrawal history for new wallet
    setDepositHistory([]) // Reset deposit history for new wallet
  }

  const handlePasswordCancel = () => {
    setShowPasswordAuth(false)
    setPendingWalletName("")
  }

  const handleBackToSearch = () => {
    setWalletInfo(null)
    setCurrentWallet("")
    setSearchQuery("")
    setUpdateStatus("none")
    setUpdateMessage("")
    setNewTrade(null)
    setWithdrawalHistory([])
    setDepositHistory([])
    setShowWithdrawalHistory(false)
  }

  const handleUpdateRequest = () => {
    // Only allow update if there's no pending request
    if (!walletInfo.lastUpdateRequest) {
      const updatedWalletData = { ...walletData }
      updatedWalletData[currentWallet].lastUpdateRequest = new Date().getTime()

      setWalletData(updatedWalletData)
      setWalletInfo({ ...walletInfo, lastUpdateRequest: new Date().getTime() })
      setUpdateStatus("pending")
      setUpdateMessage("Balance update requested. Check back after 24 hours.")
    }
  }

  // Calculate time remaining until next update
  const getTimeRemaining = () => {
    if (!walletInfo || !walletInfo.lastUpdateRequest) return null

    const now = new Date().getTime()
    const lastRequest = walletInfo.lastUpdateRequest
    const hoursSinceRequest = (now - lastRequest) / (1000 * 60 * 60)

    if (hoursSinceRequest >= 24) return "Ready to update"

    const hoursRemaining = Math.ceil(24 - hoursSinceRequest)
    return `${hoursRemaining} hours remaining`
  }

  // Handle withdrawal completion
  const handleWithdrawalComplete = (withdrawalData: any) => {
    // Update wallet balance
    if (walletInfo && currentWallet) {
      const updatedWalletData = { ...walletData }
      updatedWalletData[currentWallet].balance -= withdrawalData.amount
      setWalletData(updatedWalletData)
      setWalletInfo({ ...walletInfo, balance: walletInfo.balance - withdrawalData.amount })

      // Add to withdrawal history
      setWithdrawalHistory((prev) => [withdrawalData, ...prev])

      // Show notification
      setWithdrawalNotification(
        `Withdrawal request for ${withdrawalData.amount.toLocaleString()} USDT has been submitted. You will receive email updates about the status.`,
      )

      // Clear notification after 10 seconds
      setTimeout(() => {
        setWithdrawalNotification(null)
      }, 10000)
    }
  }

  // Handle deposit completion
  const handleDepositComplete = (amount: number, currency: string) => {
    // Update wallet balance (convert to USDT for simplicity)
    if (walletInfo && currentWallet) {
      const updatedWalletData = { ...walletData }
      updatedWalletData[currentWallet].balance += amount
      setWalletData(updatedWalletData)
      setWalletInfo({ ...walletInfo, balance: walletInfo.balance + amount })

      // Add to deposit history
      const depositData = {
        id: `D-${Math.floor(100000 + Math.random() * 900000)}`,
        date: new Date().toISOString().split("T")[0],
        amount: amount,
        currency: currency,
        status: "completed",
        txId: `0x${Math.random().toString(16).substring(2, 42)}`,
      }

      setDepositHistory((prev) => [depositData, ...prev])

      // Show notification
      setDepositNotification(
        `Deposit of ${amount.toLocaleString()} ${currency.toUpperCase()} has been confirmed and added to your balance.`,
      )

      // Clear notification after 10 seconds
      setTimeout(() => {
        setDepositNotification(null)
      }, 10000)
    }
  }

  // Handle registration success
  const handleRegisterSuccess = (walletName: string) => {
    // Create a new wallet
    const newWalletData = {
      ...walletData,
      [walletName.toLowerCase()]: {
        balance: 0,
        winRate: 0,
        profitFactor: 0,
        drawdown: 0,
        dailyTrades: 0,
        percentChange: 0,
        lastUpdateRequest: null,
        dayCounter: 0,
        currentDate: CURRENT_DATE,
        lastUpdated: CURRENT_DATE,
      },
    }

    setWalletData(newWalletData)
    setCurrentWallet(walletName.toLowerCase())
    setWalletInfo(newWalletData[walletName.toLowerCase()])
    setShowRegisterForm(false)
  }

  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" })
  }

  if (showAdminPanel) {
    return <AdminPanel onClose={() => setShowAdminPanel(false)} />
  }

  if (showUserProfile) {
    return <UserProfile walletName={currentWallet} onClose={() => setShowUserProfile(false)} />
  }

  if (showRegisterForm) {
    return (
      <RegisterForm
        referralCode={referralCode}
        onRegisterSuccess={handleRegisterSuccess}
        onCancel={() => setShowRegisterForm(false)}
      />
    )
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-10 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between py-4">
          {walletInfo && isMobile ? (
            <Button variant="ghost" size="icon" onClick={handleBackToSearch} className="mr-2">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          ) : null}
          <ScalpBotLogo className={isMobile && walletInfo ? "text-sm" : ""} />
          <div className="flex items-center gap-2">
            {walletInfo ? (
              <>
                {!isMobile && (
                  <Button variant="outline" size="sm" onClick={handleBackToSearch}>
                    Search Again
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowUserProfile(true)}
                  className="text-muted-foreground"
                >
                  <User className="h-4 w-4" />
                  <span className="sr-only">Profile</span>
                </Button>
              </>
            ) : (
              <>
                <Button variant="outline" size="sm" onClick={() => setShowRegisterForm(true)}>
                  <UserPlus className="h-4 w-4 mr-2" />
                  <span>Sign Up</span>
                </Button>
                <Button variant="ghost" size="sm" onClick={handleAdminAccess} className="text-muted-foreground">
                  <Shield className="h-4 w-4" />
                  <span className="sr-only">Admin</span>
                </Button>
              </>
            )}
          </div>
        </div>
      </header>

      <main className="flex-1 container py-4 md:py-6 px-3 md:px-4">
        {showPasswordAuth && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <PasswordAuth
              walletName={pendingWalletName}
              onSuccess={handlePasswordSuccess}
              onCancel={handlePasswordCancel}
            />
          </div>
        )}
        {showAdminLogin && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <AdminLogin onSuccess={handleAdminLoginSuccess} onCancel={handleAdminLoginCancel} />
          </div>
        )}

        {!walletInfo ? (
          // Initial search page - simplified
          <div className="flex flex-col items-center justify-center min-h-[80vh]">
            <div className="w-full max-w-md mx-auto text-center px-4">
              <h1 className="text-2xl md:text-3xl font-bold mb-8 md:mb-10">Scalp Trading BOT</h1>

              <div className="flex flex-col gap-4">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Write wallet name"
                    className="pl-9 h-12"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                  />
                </div>
                <Button onClick={handleSearch} disabled={!searchQuery.trim()} className="h-12">
                  <LogIn className="h-4 w-4 mr-2" />
                  Check Balance
                </Button>
                <Button variant="outline" onClick={() => setShowRegisterForm(true)} className="h-12">
                  <UserPlus className="h-4 w-4 mr-2" />
                  Create New Wallet
                </Button>
              </div>

              {searchError && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mt-6">{searchError}</div>
              )}
            </div>
          </div>
        ) : showWithdrawalHistory ? (
          // Withdrawal History View
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Transaction History</h2>
              <Button variant="outline" onClick={() => setShowWithdrawalHistory(false)}>
                Back to Dashboard
              </Button>
            </div>

            {withdrawalHistory.length > 0 || depositHistory.length > 0 ? (
              <Card>
                <CardContent className="pt-6">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Method/Currency</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {/* Combine and sort both histories by date */}
                      {[
                        ...withdrawalHistory.map((w) => ({ ...w, type: "withdrawal" })),
                        ...depositHistory.map((d) => ({ ...d, type: "deposit" })),
                      ]
                        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                        .map((transaction) => (
                          <TableRow key={transaction.id}>
                            <TableCell className="font-medium">{transaction.id}</TableCell>
                            <TableCell>
                              <Badge variant={transaction.type === "withdrawal" ? "destructive" : "default"}>
                                {transaction.type === "withdrawal" ? "Withdrawal" : "Deposit"}
                              </Badge>
                            </TableCell>
                            <TableCell>{formatDate(transaction.date)}</TableCell>
                            <TableCell>
                              {transaction.amount.toLocaleString()} {transaction.currency?.toUpperCase() || "USDT"}
                            </TableCell>
                            <TableCell>{transaction.method || transaction.currency?.toUpperCase()}</TableCell>
                            <TableCell>
                              <StatusBadge status={transaction.status} />
                            </TableCell>
                          </TableRow>
                        ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardContent className="py-12 text-center">
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-gray-100 mb-4">
                    <History className="h-6 w-6 text-gray-500" />
                  </div>
                  <h3 className="text-lg font-medium mb-2">No transaction history</h3>
                  <p className="text-muted-foreground max-w-md mx-auto">
                    You haven't made any deposits or withdrawals yet. When you do, they will appear here.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        ) : (
          // Wallet dashboard after search
          <>
            <div className="mb-4 md:mb-6">
              {!isMobile && (
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
                  <div>
                    <h1 className="text-2xl md:text-3xl font-bold tracking-tight capitalize">
                      {currentWallet}'s Dashboard
                    </h1>
                    <p className="text-muted-foreground text-sm">Viewing trading performance and balance history.</p>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <p className="text-sm">{formatDisplayDate(walletInfo.currentDate)}</p>
                    </div>
                    {walletInfo.lastUpdateRequest ? (
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <p className="text-sm text-muted-foreground">{getTimeRemaining()}</p>
                      </div>
                    ) : (
                      <Button onClick={handleUpdateRequest} className="flex items-center gap-2">
                        <RefreshCw className="h-4 w-4" />
                        Request Balance Update
                      </Button>
                    )}
                  </div>
                </div>
              )}
              {isMobile && (
                <div>
                  <h1 className="text-xl font-bold tracking-tight capitalize">{currentWallet}'s Dashboard</h1>
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-1">
                      <Calendar className="h-3 w-3 text-muted-foreground" />
                      <p className="text-xs">{formatDisplayDate(walletInfo.currentDate)}</p>
                    </div>
                    {walletInfo.lastUpdateRequest ? (
                      <div className="flex items-center gap-1">
                        <Clock className="h-3 w-3 text-muted-foreground" />
                        <p className="text-xs text-muted-foreground">{getTimeRemaining()}</p>
                      </div>
                    ) : (
                      <Button onClick={handleUpdateRequest} size="sm" className="h-8 text-xs">
                        Request Update
                      </Button>
                    )}
                  </div>
                </div>
              )}
            </div>

            {updateStatus !== "none" && (
              <Alert
                className={`mb-4 ${updateStatus === "updated" ? "bg-green-50 border-green-200" : "bg-blue-50 border-blue-200"}`}
              >
                <AlertTitle className={updateStatus === "updated" ? "text-green-700" : "text-blue-700"}>
                  {updateStatus === "updated" ? "Balance Updated" : "Update Requested"}
                </AlertTitle>
                <AlertDescription className={updateStatus === "updated" ? "text-green-600" : "text-blue-600"}>
                  {updateMessage}
                </AlertDescription>
              </Alert>
            )}

            {withdrawalNotification && (
              <Alert className="mb-4 bg-green-50 border-green-200">
                <AlertDescription className="text-green-600">{withdrawalNotification}</AlertDescription>
              </Alert>
            )}

            {depositNotification && (
              <Alert className="mb-4 bg-green-50 border-green-200">
                <AlertDescription className="text-green-600">{depositNotification}</AlertDescription>
              </Alert>
            )}

            <Card>
              <CardHeader className="pb-2 pt-4 px-4">
                <CardDescription className="text-xs md:text-sm">Current Balance</CardDescription>
                <CardTitle className="text-2xl md:text-4xl font-bold">
                  {walletInfo.balance.toLocaleString(undefined, {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2,
                  })}{" "}
                  USDT
                </CardTitle>
              </CardHeader>
              <CardContent className="pb-4 px-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center text-xs md:text-sm">
                    <span className="text-green-600 font-medium">+{walletInfo.percentChange}%</span>
                    <span className="text-muted-foreground ml-2">in the last 3 months</span>
                  </div>
                  <div className="flex gap-2">
                    {(withdrawalHistory.length > 0 || depositHistory.length > 0) && (
                      <Button
                        variant="outline"
                        size={isMobile ? "sm" : "default"}
                        onClick={() => setShowWithdrawalHistory(true)}
                        className="flex items-center gap-1"
                      >
                        <History className="h-4 w-4" />
                        {!isMobile && <span>History</span>}
                      </Button>
                    )}
                    <Button
                      variant="outline"
                      size={isMobile ? "sm" : "default"}
                      onClick={() => setDepositDialogOpen(true)}
                      className="flex items-center gap-1"
                    >
                      <Upload className="h-4 w-4" />
                      {!isMobile && <span>Deposit</span>}
                    </Button>
                    <Button
                      variant="outline"
                      size={isMobile ? "sm" : "default"}
                      onClick={() => setWithdrawDialogOpen(true)}
                      className="bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100 hover:text-blue-800 flex items-center gap-1"
                    >
                      <Download className="h-4 w-4" />
                      {!isMobile && <span>Withdraw</span>}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-4 mt-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-1 pt-3 px-3 md:px-4">
                  <CardTitle className="text-xs md:text-sm font-medium">Win Rate</CardTitle>
                </CardHeader>
                <CardContent className="pb-3 px-3 md:px-4">
                  <div className="text-lg md:text-2xl font-bold">{walletInfo.winRate}%</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-1 pt-3 px-3 md:px-4">
                  <CardTitle className="text-xs md:text-sm font-medium">Profit Factor</CardTitle>
                </CardHeader>
                <CardContent className="pb-3 px-3 md:px-4">
                  <div className="text-lg md:text-2xl font-bold">{walletInfo.profitFactor}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-1 pt-3 px-3 md:px-4">
                  <CardTitle className="text-xs md:text-sm font-medium">Drawdown</CardTitle>
                </CardHeader>
                <CardContent className="pb-3 px-3 md:px-4">
                  <div className="text-lg md:text-2xl font-bold">{walletInfo.drawdown}%</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-1 pt-3 px-3 md:px-4">
                  <CardTitle className="text-xs md:text-sm font-medium">Daily Trades</CardTitle>
                </CardHeader>
                <CardContent className="pb-3 px-3 md:px-4">
                  <div className="text-lg md:text-2xl font-bold">{walletInfo.dailyTrades}</div>
                </CardContent>
              </Card>
            </div>

            <BalanceChart walletName={currentWallet} isMobile={isMobile} currentDate={walletInfo.currentDate} />
            <ProfitSummary walletName={currentWallet} isMobile={isMobile} />
            <RecentTrades
              walletName={currentWallet}
              isMobile={isMobile}
              newTrade={newTrade}
              currentDate={walletInfo.currentDate}
            />
          </>
        )}
        <WithdrawDialog
          open={withdrawDialogOpen}
          onOpenChange={setWithdrawDialogOpen}
          walletBalance={walletInfo?.balance || 0}
          onWithdrawalComplete={handleWithdrawalComplete}
        />
        <DepositDialog
          open={depositDialogOpen}
          onOpenChange={setDepositDialogOpen}
          onDepositComplete={handleDepositComplete}
        />
      </main>
    </div>
  )
}
