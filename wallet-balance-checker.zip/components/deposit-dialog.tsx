"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { AlertCircle, Copy, ExternalLink, RefreshCw } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"

// Crypto options for deposit
const DEPOSIT_METHODS = [
  {
    id: "sol",
    name: "Solana (SOL)",
    icon: "/placeholder.svg?height=24&width=24",
    minDeposit: 0.1,
  },
  {
    id: "btc",
    name: "Bitcoin (BTC)",
    icon: "/placeholder.svg?height=24&width=24",
    minDeposit: 0.001,
  },
  {
    id: "eth",
    name: "Ethereum (ETH)",
    icon: "/placeholder.svg?height=24&width=24",
    minDeposit: 0.01,
  },
  {
    id: "usdt",
    name: "USDT (Tether)",
    icon: "/placeholder.svg?height=24&width=24",
    minDeposit: 10,
  },
]

export function DepositDialog({
  open,
  onOpenChange,
  onDepositComplete,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  onDepositComplete?: (amount: number, currency: string) => void
}) {
  const [selectedMethod, setSelectedMethod] = useState("sol")
  const [depositAddress, setDepositAddress] = useState("")
  const [addressCopied, setAddressCopied] = useState(false)
  const [isGeneratingAddress, setIsGeneratingAddress] = useState(false)
  const [depositAmount, setDepositAmount] = useState("")
  const [depositStep, setDepositStep] = useState<"select" | "address" | "confirmation">("select")
  const [depositStatus, setDepositStatus] = useState<"pending" | "confirmed" | "failed">("pending")

  // Generate a new deposit address when the method changes
  useEffect(() => {
    if (depositStep === "address") {
      generateNewAddress()
    }
  }, [selectedMethod, depositStep])

  const generateNewAddress = () => {
    setIsGeneratingAddress(true)

    // Simulate address generation
    setTimeout(() => {
      // Generate random addresses based on the selected method
      let newAddress = ""

      if (selectedMethod === "sol") {
        newAddress = `${randomString(8)}${randomString(8)}${randomString(8)}${randomString(8)}`
      } else if (selectedMethod === "btc") {
        newAddress = `bc1q${randomString(38)}`
      } else if (selectedMethod === "eth") {
        newAddress = `0x${randomString(40)}`
      } else {
        newAddress = `0x${randomString(40)}`
      }

      setDepositAddress(newAddress)
      setIsGeneratingAddress(false)
    }, 1500)
  }

  const randomString = (length: number) => {
    const chars = "abcdefghijklmnopqrstuvwxyz0123456789"
    let result = ""
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length))
    }
    return result
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(depositAddress)
    setAddressCopied(true)
    setTimeout(() => setAddressCopied(false), 3000)
  }

  const handleContinue = () => {
    if (depositStep === "select") {
      setDepositStep("address")
    } else if (depositStep === "address") {
      // Simulate deposit confirmation
      setDepositStep("confirmation")

      // Simulate deposit processing
      setTimeout(() => {
        setDepositStatus("confirmed")

        // Notify parent component
        if (onDepositComplete) {
          const amount =
            Number.parseFloat(depositAmount) || DEPOSIT_METHODS.find((m) => m.id === selectedMethod)?.minDeposit || 0
          onDepositComplete(amount, selectedMethod)
        }
      }, 3000)
    }
  }

  const handleClose = () => {
    // Reset state when closing
    if (depositStatus === "confirmed") {
      setDepositStep("select")
      setDepositStatus("pending")
      setDepositAmount("")
    }
    onOpenChange(false)
  }

  const selectedMethodInfo = DEPOSIT_METHODS.find((method) => method.id === selectedMethod)

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Deposit Funds</DialogTitle>
          <DialogDescription>Add funds to your wallet by depositing cryptocurrency.</DialogDescription>
        </DialogHeader>

        {depositStep === "select" && (
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Select Cryptocurrency</Label>
              <RadioGroup value={selectedMethod} onValueChange={setSelectedMethod} className="gap-2">
                {DEPOSIT_METHODS.map((method) => (
                  <div
                    key={method.id}
                    className={`flex items-center space-x-2 border rounded-md p-3 cursor-pointer transition-colors ${
                      selectedMethod === method.id ? "border-blue-500 bg-blue-50" : "border-gray-200 hover:bg-gray-50"
                    }`}
                    onClick={() => setSelectedMethod(method.id)}
                  >
                    <RadioGroupItem value={method.id} id={method.id} className="sr-only" />
                    <img src={method.icon || "/placeholder.svg"} alt={method.name} className="w-6 h-6 mr-2" />
                    <div className="flex-1">
                      <Label htmlFor={method.id} className="cursor-pointer">
                        {method.name}
                      </Label>
                      <p className="text-xs text-muted-foreground">
                        Min. deposit: {method.minDeposit} {method.id.toUpperCase()}
                      </p>
                    </div>
                  </div>
                ))}
              </RadioGroup>
            </div>

            <div className="space-y-2">
              <Label htmlFor="depositAmount">Deposit Amount (Optional)</Label>
              <div className="relative">
                <Input
                  id="depositAmount"
                  type="number"
                  placeholder={`Enter amount in ${selectedMethod.toUpperCase()}`}
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(e.target.value)}
                  min={selectedMethodInfo?.minDeposit}
                  step="0.000001"
                />
              </div>
              <p className="text-xs text-muted-foreground">
                If you don't specify an amount, we'll credit your account based on the actual deposit received.
              </p>
            </div>

            <Alert className="bg-blue-50 border-blue-200">
              <AlertCircle className="h-4 w-4 text-blue-600" />
              <AlertDescription className="text-blue-700">
                Deposits are typically credited within 10-30 minutes after network confirmation.
              </AlertDescription>
            </Alert>
          </div>
        )}

        {depositStep === "address" && (
          <div className="space-y-4 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <img
                  src={selectedMethodInfo?.icon || "/placeholder.svg"}
                  alt={selectedMethodInfo?.name}
                  className="w-6 h-6 mr-2"
                />
                <h3 className="font-medium">{selectedMethodInfo?.name}</h3>
              </div>
              <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                {depositAmount ? `${depositAmount} ${selectedMethod.toUpperCase()}` : "Any amount"}
              </Badge>
            </div>

            <div className="space-y-2">
              <Label>Deposit Address</Label>
              <div className="flex">
                <Input value={depositAddress} readOnly className="rounded-r-none font-mono text-sm" />
                <Button
                  onClick={copyToClipboard}
                  variant="secondary"
                  className="rounded-l-none"
                  disabled={isGeneratingAddress}
                >
                  {addressCopied ? "Copied!" : <Copy className="h-4 w-4" />}
                </Button>
              </div>
              <div className="flex justify-between items-center">
                <p className="text-xs text-muted-foreground">
                  Send only {selectedMethod.toUpperCase()} to this address
                </p>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={generateNewAddress}
                  disabled={isGeneratingAddress}
                  className="h-6 text-xs"
                >
                  <RefreshCw className="h-3 w-3 mr-1" />
                  New Address
                </Button>
              </div>
            </div>

            <div className="flex justify-center py-4">
              {isGeneratingAddress ? (
                <div className="flex flex-col items-center">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mb-2"></div>
                  <p className="text-sm text-muted-foreground">Generating new address...</p>
                </div>
              ) : (
                <div className="flex flex-col items-center">
                  <div className="border-2 border-gray-300 rounded-md p-2 mb-2">
                    <div className="bg-white w-[150px] h-[150px] flex items-center justify-center relative">
                      <div className="absolute inset-4 grid grid-cols-4 grid-rows-4 gap-1">
                        {Array.from({ length: 16 }).map((_, i) => (
                          <div
                            key={i}
                            className={`rounded-sm ${
                              // Create a pattern that looks like a QR code
                              [0, 3, 4, 7, 8, 11, 12, 15].includes(i)
                                ? "bg-black"
                                : Math.random() > 0.6
                                  ? "bg-black"
                                  : "bg-white"
                            }`}
                          />
                        ))}
                      </div>
                      <div className="bg-white p-2 z-10 text-xs text-center">
                        <span className="font-mono text-[8px] break-all">{depositAddress.substring(0, 10)}...</span>
                      </div>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground">Copy address to deposit</p>
                  <p className="text-xs text-blue-600 mt-1">QR code scanning available in app</p>
                </div>
              )}
            </div>

            <Alert className="bg-amber-50 border-amber-200">
              <AlertCircle className="h-4 w-4 text-amber-600" />
              <AlertDescription className="text-amber-700">
                Important: Send only {selectedMethod.toUpperCase()} to this address. Sending any other cryptocurrency
                may result in permanent loss of funds.
              </AlertDescription>
            </Alert>
          </div>
        )}

        {depositStep === "confirmation" && (
          <div className="space-y-4 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <img
                  src={selectedMethodInfo?.icon || "/placeholder.svg"}
                  alt={selectedMethodInfo?.name}
                  className="w-6 h-6 mr-2"
                />
                <h3 className="font-medium">{selectedMethodInfo?.name}</h3>
              </div>
              <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                {depositAmount ? `${depositAmount} ${selectedMethod.toUpperCase()}` : "Any amount"}
              </Badge>
            </div>

            {depositStatus === "pending" ? (
              <div className="flex flex-col items-center py-6">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mb-4"></div>
                <h3 className="text-lg font-medium mb-2">Processing Deposit</h3>
                <p className="text-muted-foreground text-center mb-4">
                  We're waiting for network confirmation of your deposit. This usually takes 10-30 minutes.
                </p>
                <div className="w-full bg-gray-200 rounded-full h-2.5 mb-4">
                  <div className="bg-blue-600 h-2.5 rounded-full w-[45%]"></div>
                </div>
                <p className="text-sm text-muted-foreground">You can close this window and check your balance later.</p>
              </div>
            ) : depositStatus === "confirmed" ? (
              <div className="flex flex-col items-center py-6">
                <div className="bg-green-100 p-3 rounded-full mb-4">
                  <svg
                    className="h-6 w-6 text-green-600"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                  </svg>
                </div>
                <h3 className="text-lg font-medium mb-2">Deposit Confirmed!</h3>
                <p className="text-muted-foreground text-center mb-4">
                  Your deposit of {depositAmount || "cryptocurrency"} has been confirmed and added to your balance.
                </p>
                <Button variant="outline" size="sm" className="flex items-center gap-1">
                  <ExternalLink className="h-4 w-4 mr-1" />
                  View Transaction
                </Button>
              </div>
            ) : (
              <div className="flex flex-col items-center py-6">
                <div className="bg-red-100 p-3 rounded-full mb-4">
                  <svg
                    className="h-6 w-6 text-red-600"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                  </svg>
                </div>
                <h3 className="text-lg font-medium mb-2">Deposit Failed</h3>
                <p className="text-muted-foreground text-center mb-4">
                  We couldn't process your deposit. Please try again or contact support if the issue persists.
                </p>
                <Button variant="outline" onClick={() => setDepositStep("select")}>
                  Try Again
                </Button>
              </div>
            )}
          </div>
        )}

        <DialogFooter>
          {depositStep === "select" && <Button onClick={handleContinue}>Continue</Button>}
          {depositStep === "address" && (
            <Button onClick={handleContinue} disabled={isGeneratingAddress || !depositAddress}>
              I've Sent the Deposit
            </Button>
          )}
          {depositStep === "confirmation" && depositStatus === "confirmed" && (
            <Button onClick={handleClose}>Close</Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
