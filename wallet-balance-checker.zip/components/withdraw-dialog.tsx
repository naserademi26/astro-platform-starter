"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { AlertCircle, CheckCircle2, Upload, DollarSign } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { EmailVerification } from "@/components/email-verification"
import { WithdrawalMethods } from "@/components/withdrawal-methods"
import { KycVerification } from "@/components/kyc-verification"

type WithdrawStep =
  | "amount"
  | "upload-passport"
  | "upload-address"
  | "withdrawal-method"
  | "contact-info"
  | "email-verification"
  | "kyc-verification"
  | "confirmation"

export function WithdrawDialog({
  open,
  onOpenChange,
  walletBalance = 0,
  onWithdrawalComplete,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  walletBalance?: number
  onWithdrawalComplete?: (withdrawalData: any) => void
}) {
  const [currentStep, setCurrentStep] = useState<WithdrawStep>("amount")
  const [withdrawAmount, setWithdrawAmount] = useState("")
  const [amountError, setAmountError] = useState("")
  const [passportFile, setPassportFile] = useState<File | null>(null)
  const [addressFile, setAddressFile] = useState<File | null>(null)
  const [email, setEmail] = useState("")
  const [withdrawalMethod, setWithdrawalMethod] = useState("")
  const [withdrawalAddress, setWithdrawalAddress] = useState("")
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [kycVerified, setKycVerified] = useState(false)

  const handleNext = () => {
    if (currentStep === "amount") {
      // Validate amount
      const amount = Number.parseFloat(withdrawAmount)
      if (isNaN(amount) || amount <= 0) {
        setAmountError("Please enter a valid amount")
        return
      }
      if (amount > walletBalance) {
        setAmountError("Insufficient balance")
        return
      }
      setAmountError("")
      setCurrentStep("upload-passport")
    } else if (currentStep === "upload-passport") {
      setCurrentStep("upload-address")
    } else if (currentStep === "upload-address") {
      setCurrentStep("withdrawal-method")
    } else if (currentStep === "withdrawal-method") {
      setCurrentStep("contact-info")
    } else if (currentStep === "contact-info") {
      setCurrentStep("email-verification")
    } else if (currentStep === "email-verification") {
      setCurrentStep("confirmation")
      setIsSubmitted(true)
      setKycVerified(true)

      // Create withdrawal data
      const withdrawalData = {
        id: `W-${Math.floor(100000 + Math.random() * 900000)}`,
        date: new Date().toISOString().split("T")[0],
        amount: Number.parseFloat(withdrawAmount),
        method: withdrawalMethod,
        address: withdrawalAddress,
        email: email,
        status: "pending",
      }

      // Notify parent component about the withdrawal
      if (onWithdrawalComplete) {
        onWithdrawalComplete(withdrawalData)
      }
    } else if (currentStep === "kyc-verification") {
      setCurrentStep("confirmation")
      setIsSubmitted(true)
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, type: "passport" | "address") => {
    if (e.target.files && e.target.files[0]) {
      if (type === "passport") {
        setPassportFile(e.target.files[0])
      } else {
        setAddressFile(e.target.files[0])
      }
    }
  }

  const resetForm = () => {
    setCurrentStep("amount")
    setWithdrawAmount("")
    setAmountError("")
    setPassportFile(null)
    setAddressFile(null)
    setEmail("")
    setWithdrawalMethod("")
    setWithdrawalAddress("")
    setIsSubmitted(false)
  }

  const handleClose = () => {
    if (isSubmitted) {
      resetForm()
    }
    onOpenChange(false)
  }

  const handleWithdrawalMethodSelect = (method: string, address: string) => {
    setWithdrawalMethod(method)
    setWithdrawalAddress(address)
    handleNext()
  }

  const handleEmailVerificationSuccess = () => {
    handleNext()
  }

  const handleKycComplete = () => {
    setKycVerified(true)
    handleNext()
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(value)
  }

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className={`${currentStep === "kyc-verification" ? "sm:max-w-3xl" : "sm:max-w-[500px]"}`}>
        <DialogHeader>
          <DialogTitle>Withdraw Funds</DialogTitle>
          <DialogDescription>Complete the verification process to withdraw your funds.</DialogDescription>
        </DialogHeader>

        {currentStep === "amount" && (
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="withdrawAmount">Withdrawal Amount (USDT)</Label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="withdrawAmount"
                  type="number"
                  placeholder="Enter amount"
                  className="pl-9"
                  value={withdrawAmount}
                  onChange={(e) => {
                    setWithdrawAmount(e.target.value)
                    setAmountError("")
                  }}
                  min={1}
                  max={walletBalance}
                  step="0.01"
                />
              </div>
              {amountError && <p className="text-sm text-red-500">{amountError}</p>}
              <p className="text-xs text-muted-foreground">Available balance: {formatCurrency(walletBalance)} USDT</p>
            </div>

            <Alert className="bg-blue-50 border-blue-200">
              <AlertCircle className="h-4 w-4 text-blue-600" />
              <AlertDescription className="text-blue-700">
                Minimum withdrawal amount is 10 USDT. Withdrawals are processed within 24-48 hours.
              </AlertDescription>
            </Alert>
          </div>
        )}

        {currentStep === "upload-passport" && (
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="passport">Upload Passport</Label>
              <div className="border-2 border-dashed rounded-md p-6 flex flex-col items-center justify-center">
                <Upload className="h-10 w-10 text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground mb-2">Upload a clear photo or scan of your passport</p>
                <Input
                  id="passport"
                  type="file"
                  className="hidden"
                  accept="image/*,.pdf"
                  onChange={(e) => handleFileChange(e, "passport")}
                />
                <Button variant="outline" onClick={() => document.getElementById("passport")?.click()} className="mt-2">
                  Select File
                </Button>
                {passportFile && (
                  <div className="mt-4 flex items-center gap-2 text-sm text-green-600">
                    <CheckCircle2 className="h-4 w-4" />
                    <span>{passportFile.name}</span>
                  </div>
                )}
              </div>
            </div>

            <Alert variant="default" className="bg-amber-50 border-amber-200">
              <AlertCircle className="h-4 w-4 text-amber-600" />
              <AlertTitle className="text-amber-800">Important</AlertTitle>
              <AlertDescription className="text-amber-700">
                Your passport must be valid and clearly visible. We use this for identity verification.
              </AlertDescription>
            </Alert>
          </div>
        )}

        {currentStep === "upload-address" && (
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="address">Proof of Address</Label>
              <div className="border-2 border-dashed rounded-md p-6 flex flex-col items-center justify-center">
                <Upload className="h-10 w-10 text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground mb-2">
                  Upload a utility bill or bank statement (less than 3 months old)
                </p>
                <Input
                  id="address"
                  type="file"
                  className="hidden"
                  accept="image/*,.pdf"
                  onChange={(e) => handleFileChange(e, "address")}
                />
                <Button variant="outline" onClick={() => document.getElementById("address")?.click()} className="mt-2">
                  Select File
                </Button>
                {addressFile && (
                  <div className="mt-4 flex items-center gap-2 text-sm text-green-600">
                    <CheckCircle2 className="h-4 w-4" />
                    <span>{addressFile.name}</span>
                  </div>
                )}
              </div>
            </div>

            <Alert variant="default" className="bg-amber-50 border-amber-200">
              <AlertCircle className="h-4 w-4 text-amber-600" />
              <AlertTitle className="text-amber-800">Important</AlertTitle>
              <AlertDescription className="text-amber-700">
                Your proof of address must show your full name and current address, and be dated within the last 3
                months.
              </AlertDescription>
            </Alert>
          </div>
        )}

        {currentStep === "withdrawal-method" && (
          <WithdrawalMethods
            onSelect={handleWithdrawalMethodSelect}
            onCancel={() => setCurrentStep("upload-address")}
          />
        )}

        {currentStep === "contact-info" && (
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email Address</Label>
              <Input
                id="email"
                type="email"
                placeholder="your.email@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
              <p className="text-xs text-muted-foreground">
                We'll use this email to contact you about your withdrawal and send verification code.
              </p>
            </div>

            <Alert className="bg-blue-50 border-blue-200">
              <AlertCircle className="h-4 w-4 text-blue-600" />
              <AlertDescription className="text-blue-700">
                A verification code will be sent to this email in the next step.
              </AlertDescription>
            </Alert>
          </div>
        )}

        {currentStep === "email-verification" && (
          <EmailVerification
            email={email}
            onSuccess={handleEmailVerificationSuccess}
            onCancel={() => setCurrentStep("contact-info")}
          />
        )}

        {currentStep === "kyc-verification" && (
          <KycVerification onComplete={handleKycComplete} onCancel={() => setCurrentStep("email-verification")} />
        )}

        {currentStep === "confirmation" && (
          <div className="py-6 flex flex-col items-center text-center">
            <div className="bg-green-100 p-3 rounded-full mb-4">
              <CheckCircle2 className="h-8 w-8 text-green-600" />
            </div>
            <h3 className="text-lg font-medium mb-2">Withdrawal Request Submitted</h3>
            <p className="text-muted-foreground mb-4">
              We've received your withdrawal request for {Number.parseFloat(withdrawAmount).toLocaleString()} USDT. Our
              team will review your submission and process your withdrawal within 24-48 hours.
            </p>
            <div className="bg-gray-50 border rounded-md p-4 w-full text-left mb-4">
              <h4 className="font-medium mb-2">Withdrawal Details</h4>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div>
                  <span className="text-muted-foreground">Amount:</span>
                  <p className="font-medium">{Number.parseFloat(withdrawAmount).toLocaleString()} USDT</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Method:</span>
                  <p>{withdrawalMethod}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Address:</span>
                  <p className="truncate">{withdrawalAddress}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Email:</span>
                  <p>{email}</p>
                </div>
              </div>
            </div>
            <Alert variant="default" className="bg-blue-50 border-blue-200 text-left">
              <AlertTitle className="text-blue-800">Next Steps</AlertTitle>
              <AlertDescription className="text-blue-700">
                <p className="mb-1">You will receive email notifications about:</p>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Withdrawal status updates</li>
                  <li>Verification status</li>
                  <li>Completion of your withdrawal</li>
                </ul>
                <p className="mt-2">Please check your email ({email}) regularly for these updates.</p>
              </AlertDescription>
            </Alert>
          </div>
        )}

        {currentStep !== "withdrawal-method" &&
          currentStep !== "email-verification" &&
          currentStep !== "kyc-verification" && (
            <DialogFooter>
              {currentStep !== "confirmation" ? (
                <Button
                  onClick={handleNext}
                  disabled={
                    currentStep === "amount" && (withdrawAmount === "" || Number.parseFloat(withdrawAmount) <= 0)
                  }
                >
                  {currentStep === "contact-info" ? "Continue to Verification" : "Next"}
                </Button>
              ) : (
                <Button onClick={handleClose}>Close</Button>
              )}
            </DialogFooter>
          )}
      </DialogContent>
    </Dialog>
  )
}
