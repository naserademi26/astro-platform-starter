"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { AlertCircle, Mail } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

export function EmailVerification({
  email,
  onSuccess,
  onCancel,
}: {
  email: string
  onSuccess: () => void
  onCancel: () => void
}) {
  const [code, setCode] = useState("")
  const [error, setError] = useState("")
  const [timeLeft, setTimeLeft] = useState(60)
  const [isResending, setIsResending] = useState(false)

  // Generate a random 6-digit code
  const [validCode, setValidCode] = useState("")

  useEffect(() => {
    // Generate a random 6-digit code
    setValidCode(Math.floor(100000 + Math.random() * 900000).toString())

    // Countdown timer
    const timer = setInterval(() => {
      setTimeLeft((prevTime) => {
        if (prevTime <= 1) {
          clearInterval(timer)
          return 0
        }
        return prevTime - 1
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [isResending])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Accept any 6-digit code for this implementation
    if (code.length === 6) {
      onSuccess()
    } else {
      setError("Invalid verification code. Please try again.")
      setCode("")
    }
  }

  const handleResendCode = () => {
    setIsResending(true)
    setTimeLeft(60)
    setError("")

    // Generate a new code
    setTimeout(() => {
      setValidCode(Math.floor(100000 + Math.random() * 900000).toString())
      setIsResending(false)
    }, 1000)
  }

  const maskedEmail = email ? email.replace(/(.{2})(.*)(@.*)/, "$1***$3") : "your email"

  return (
    <div className="space-y-4 py-4">
      <div className="flex flex-col items-center mb-6">
        <div className="bg-blue-100 p-3 rounded-full mb-4">
          <Mail className="h-8 w-8 text-blue-600" />
        </div>
        <h2 className="text-xl font-bold mb-1">Email Verification</h2>
        <p className="text-center text-muted-foreground text-sm">
          Please enter the verification code sent to {maskedEmail}
        </p>
      </div>

      {error && (
        <Alert variant="destructive" className="mb-4">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <Alert className="mb-4 bg-blue-50 border-blue-200">
        <AlertCircle className="h-4 w-4 text-blue-600" />
        <AlertDescription className="text-blue-700">
          For security purposes, we've sent a 6-digit verification code to your email address.
        </AlertDescription>
      </Alert>

      <form onSubmit={handleSubmit}>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="code">Verification Code</Label>
            <Input
              id="code"
              type="text"
              inputMode="numeric"
              pattern="[0-9]*"
              maxLength={6}
              value={code}
              onChange={(e) => setCode(e.target.value.replace(/[^0-9]/g, ""))}
              className="text-center text-lg tracking-widest"
              placeholder="• • • • • •"
              autoFocus
            />
          </div>

          <div className="text-center text-sm text-muted-foreground">
            {timeLeft > 0 ? (
              <p>Resend code in {timeLeft} seconds</p>
            ) : (
              <button
                type="button"
                onClick={handleResendCode}
                className="text-blue-600 hover:text-blue-800 hover:underline"
                disabled={isResending}
              >
                {isResending ? "Sending..." : "Resend code"}
              </button>
            )}
          </div>

          <div className="flex gap-3">
            <Button type="button" variant="outline" className="flex-1" onClick={onCancel}>
              Cancel
            </Button>
            <Button type="submit" className="flex-1" disabled={code.length !== 6}>
              Verify
            </Button>
          </div>
        </div>
      </form>
    </div>
  )
}
