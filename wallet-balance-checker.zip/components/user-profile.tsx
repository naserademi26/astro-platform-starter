"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Copy,
  User,
  Mail,
  Calendar,
  MapPin,
  Shield,
  Share2,
  Users,
  AlertCircle,
  CheckCircle,
  Upload,
} from "lucide-react"

export function UserProfile({
  walletName,
  onClose,
}: {
  walletName: string
  onClose: () => void
}) {
  const [activeTab, setActiveTab] = useState("personal")
  const [personalInfo, setPersonalInfo] = useState({
    fullName: "",
    email: "",
    dateOfBirth: "",
    address: "",
    city: "",
    country: "",
    postalCode: "",
  })
  const [passportFile, setPassportFile] = useState<File | null>(null)
  const [addressFile, setAddressFile] = useState<File | null>(null)
  const [verificationStatus, setVerificationStatus] = useState("unverified") // unverified, pending, verified
  const [referralLink, setReferralLink] = useState("")
  const [referralCopied, setReferralCopied] = useState(false)
  const [referrals, setReferrals] = useState([])
  const [showSuccessMessage, setShowSuccessMessage] = useState(false)

  // Generate a unique referral link based on wallet name
  useState(() => {
    const baseUrl = window.location.origin
    const uniqueCode = btoa(walletName + Date.now()).substring(0, 12)
    setReferralLink(`${baseUrl}/invite/${uniqueCode}`)
  }, [walletName])

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, type: "passport" | "address") => {
    if (e.target.files && e.target.files[0]) {
      if (type === "passport") {
        setPassportFile(e.target.files[0])
      } else {
        setAddressFile(e.target.files[0])
      }
    }
  }

  const handleSavePersonalInfo = () => {
    // In a real app, this would save to a database
    setShowSuccessMessage(true)
    setTimeout(() => setShowSuccessMessage(false), 3000)
  }

  const handleSubmitVerification = () => {
    // In a real app, this would submit verification documents
    setVerificationStatus("pending")
    setShowSuccessMessage(true)
    setTimeout(() => setShowSuccessMessage(false), 3000)
  }

  const copyReferralLink = () => {
    navigator.clipboard.writeText(referralLink)
    setReferralCopied(true)
    setTimeout(() => setReferralCopied(false), 3000)
  }

  return (
    <div className="bg-white min-h-screen">
      <header className="border-b bg-white sticky top-0 z-10">
        <div className="container flex items-center justify-between h-16 px-4">
          <div className="flex items-center">
            <User className="h-6 w-6 text-blue-600 mr-2" />
            <h1 className="text-xl font-bold">User Profile</h1>
          </div>
          <Button onClick={onClose} variant="outline" size="sm">
            Back to Dashboard
          </Button>
        </div>
      </header>

      <main className="container px-4 py-6">
        <div className="flex flex-col md:flex-row gap-6">
          {/* Sidebar */}
          <div className="w-full md:w-64 space-y-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg font-medium capitalize">{walletName}</CardTitle>
                <CardDescription>
                  Verification Status:{" "}
                  <Badge
                    variant="outline"
                    className={`ml-1 ${
                      verificationStatus === "verified"
                        ? "bg-green-100 text-green-800 border-green-200"
                        : verificationStatus === "pending"
                          ? "bg-yellow-100 text-yellow-800 border-yellow-200"
                          : "bg-red-100 text-red-800 border-red-200"
                    }`}
                  >
                    {verificationStatus.charAt(0).toUpperCase() + verificationStatus.slice(1)}
                  </Badge>
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col gap-1 text-sm">
                  <div className="flex items-center gap-2">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <span>{personalInfo.email || "Email not set"}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span>{personalInfo.dateOfBirth || "Date of birth not set"}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <span>{personalInfo.address ? "Address set" : "Address not set"}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Shield className="h-4 w-4 text-muted-foreground" />
                    <span>
                      {verificationStatus === "verified"
                        ? "Fully verified"
                        : verificationStatus === "pending"
                          ? "Verification in progress"
                          : "Not verified"}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="hidden md:block">
              <Tabs value={activeTab} onValueChange={setActiveTab} orientation="vertical" className="w-full">
                <TabsList className="flex flex-col h-auto w-full bg-muted/50 p-0">
                  <TabsTrigger
                    value="personal"
                    className="justify-start px-4 py-2 data-[state=active]:bg-background rounded-none border-l-2 border-transparent data-[state=active]:border-primary"
                  >
                    Personal Information
                  </TabsTrigger>
                  <TabsTrigger
                    value="verification"
                    className="justify-start px-4 py-2 data-[state=active]:bg-background rounded-none border-l-2 border-transparent data-[state=active]:border-primary"
                  >
                    Verification
                  </TabsTrigger>
                  <TabsTrigger
                    value="referrals"
                    className="justify-start px-4 py-2 data-[state=active]:bg-background rounded-none border-l-2 border-transparent data-[state=active]:border-primary"
                  >
                    Referrals
                  </TabsTrigger>
                </TabsList>
              </Tabs>
            </div>

            <div className="md:hidden">
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid grid-cols-3 w-full">
                  <TabsTrigger value="personal">Personal</TabsTrigger>
                  <TabsTrigger value="verification">Verification</TabsTrigger>
                  <TabsTrigger value="referrals">Referrals</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </div>

          {/* Main content */}
          <div className="flex-1">
            {showSuccessMessage && (
              <Alert className="mb-4 bg-green-50 border-green-200">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <AlertDescription className="text-green-600">
                  Your information has been saved successfully.
                </AlertDescription>
              </Alert>
            )}

            <TabsContent value="personal" className="mt-0 md:mt-0">
              <Card>
                <CardHeader>
                  <CardTitle>Personal Information</CardTitle>
                  <CardDescription>
                    Update your personal information. This information is used for verification purposes.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="fullName">Full Name</Label>
                      <Input
                        id="fullName"
                        value={personalInfo.fullName}
                        onChange={(e) => setPersonalInfo({ ...personalInfo, fullName: e.target.value })}
                        placeholder="Enter your full name"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email Address</Label>
                      <Input
                        id="email"
                        type="email"
                        value={personalInfo.email}
                        onChange={(e) => setPersonalInfo({ ...personalInfo, email: e.target.value })}
                        placeholder="Enter your email address"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="dateOfBirth">Date of Birth</Label>
                      <Input
                        id="dateOfBirth"
                        type="date"
                        value={personalInfo.dateOfBirth}
                        onChange={(e) => setPersonalInfo({ ...personalInfo, dateOfBirth: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="address">Address</Label>
                    <Textarea
                      id="address"
                      value={personalInfo.address}
                      onChange={(e) => setPersonalInfo({ ...personalInfo, address: e.target.value })}
                      placeholder="Enter your street address"
                      rows={2}
                    />
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="city">City</Label>
                      <Input
                        id="city"
                        value={personalInfo.city}
                        onChange={(e) => setPersonalInfo({ ...personalInfo, city: e.target.value })}
                        placeholder="City"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="postalCode">Postal Code</Label>
                      <Input
                        id="postalCode"
                        value={personalInfo.postalCode}
                        onChange={(e) => setPersonalInfo({ ...personalInfo, postalCode: e.target.value })}
                        placeholder="Postal Code"
                      />
                    </div>
                    <div className="space-y-2 col-span-2 md:col-span-1">
                      <Label htmlFor="country">Country</Label>
                      <Input
                        id="country"
                        value={personalInfo.country}
                        onChange={(e) => setPersonalInfo({ ...personalInfo, country: e.target.value })}
                        placeholder="Country"
                      />
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button onClick={handleSavePersonalInfo}>Save Information</Button>
                </CardFooter>
              </Card>
            </TabsContent>

            <TabsContent value="verification" className="mt-0 md:mt-0">
              <Card>
                <CardHeader>
                  <CardTitle>Verification Documents</CardTitle>
                  <CardDescription>
                    Upload your verification documents to increase your withdrawal limits and enhance account security.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {verificationStatus === "pending" ? (
                    <Alert className="bg-yellow-50 border-yellow-200">
                      <AlertCircle className="h-4 w-4 text-yellow-600" />
                      <AlertDescription className="text-yellow-700">
                        Your verification is currently being processed. This usually takes 24-48 hours.
                      </AlertDescription>
                    </Alert>
                  ) : verificationStatus === "verified" ? (
                    <Alert className="bg-green-50 border-green-200">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <AlertDescription className="text-green-700">
                        Your account is fully verified. You now have access to all features and higher withdrawal
                        limits.
                      </AlertDescription>
                    </Alert>
                  ) : (
                    <>
                      <div className="space-y-2">
                        <Label htmlFor="passport">Government-Issued ID or Passport</Label>
                        <div className="border-2 border-dashed rounded-md p-6 flex flex-col items-center justify-center">
                          <Upload className="h-10 w-10 text-muted-foreground mb-2" />
                          <p className="text-sm text-muted-foreground mb-2">
                            Upload a clear photo or scan of your passport or ID
                          </p>
                          <Input
                            id="passport"
                            type="file"
                            className="hidden"
                            accept="image/*,.pdf"
                            onChange={(e) => handleFileChange(e, "passport")}
                          />
                          <Button
                            variant="outline"
                            onClick={() => document.getElementById("passport")?.click()}
                            className="mt-2"
                          >
                            Select File
                          </Button>
                          {passportFile && (
                            <div className="mt-4 flex items-center gap-2 text-sm text-green-600">
                              <CheckCircle className="h-4 w-4" />
                              <span>{passportFile.name}</span>
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="addressProof">Proof of Address</Label>
                        <div className="border-2 border-dashed rounded-md p-6 flex flex-col items-center justify-center">
                          <Upload className="h-10 w-10 text-muted-foreground mb-2" />
                          <p className="text-sm text-muted-foreground mb-2">
                            Upload a utility bill or bank statement (less than 3 months old)
                          </p>
                          <Input
                            id="addressProof"
                            type="file"
                            className="hidden"
                            accept="image/*,.pdf"
                            onChange={(e) => handleFileChange(e, "address")}
                          />
                          <Button
                            variant="outline"
                            onClick={() => document.getElementById("addressProof")?.click()}
                            className="mt-2"
                          >
                            Select File
                          </Button>
                          {addressFile && (
                            <div className="mt-4 flex items-center gap-2 text-sm text-green-600">
                              <CheckCircle className="h-4 w-4" />
                              <span>{addressFile.name}</span>
                            </div>
                          )}
                        </div>
                      </div>

                      <Alert className="bg-blue-50 border-blue-200">
                        <AlertCircle className="h-4 w-4 text-blue-600" />
                        <AlertDescription className="text-blue-700">
                          Verification usually takes 24-48 hours to process. You'll be notified by email once your
                          verification is complete.
                        </AlertDescription>
                      </Alert>
                    </>
                  )}
                </CardContent>
                <CardFooter>
                  {verificationStatus === "unverified" && (
                    <Button onClick={handleSubmitVerification} disabled={!passportFile || !addressFile}>
                      Submit Verification
                    </Button>
                  )}
                </CardFooter>
              </Card>
            </TabsContent>

            <TabsContent value="referrals" className="mt-0 md:mt-0">
              <Card>
                <CardHeader>
                  <CardTitle>Referral Program</CardTitle>
                  <CardDescription>
                    Invite friends and earn 20% of their investment. Share your unique referral link.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="referralLink">Your Referral Link</Label>
                    <div className="flex">
                      <Input id="referralLink" value={referralLink} readOnly className="rounded-r-none" />
                      <Button onClick={copyReferralLink} variant="secondary" className="rounded-l-none">
                        {referralCopied ? <CheckCircle className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Share this link with friends. When they sign up and invest, you'll earn 20% of their investment.
                    </p>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label>Share Your Link</Label>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" className="flex-1">
                        <Share2 className="h-4 w-4 mr-2" />
                        Share
                      </Button>
                      <Button variant="outline" className="flex-1">
                        <Mail className="h-4 w-4 mr-2" />
                        Email
                      </Button>
                      <Button variant="outline" className="flex-1">
                        <Users className="h-4 w-4 mr-2" />
                        Contacts
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Referral Statistics</Label>
                    <div className="grid grid-cols-3 gap-4">
                      <Card>
                        <CardContent className="p-4 text-center">
                          <p className="text-2xl font-bold">0</p>
                          <p className="text-xs text-muted-foreground">Total Referrals</p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="p-4 text-center">
                          <p className="text-2xl font-bold">$0.00</p>
                          <p className="text-xs text-muted-foreground">Total Earnings</p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="p-4 text-center">
                          <p className="text-2xl font-bold">$0.00</p>
                          <p className="text-xs text-muted-foreground">Pending Earnings</p>
                        </CardContent>
                      </Card>
                    </div>
                  </div>

                  {referrals.length > 0 ? (
                    <div className="space-y-2">
                      <Label>Your Referrals</Label>
                      <div className="border rounded-md">
                        <table className="w-full">
                          <thead className="bg-muted/50">
                            <tr>
                              <th className="text-left p-2 text-xs font-medium">User</th>
                              <th className="text-left p-2 text-xs font-medium">Date</th>
                              <th className="text-right p-2 text-xs font-medium">Investment</th>
                              <th className="text-right p-2 text-xs font-medium">Your Earnings</th>
                            </tr>
                          </thead>
                          <tbody>{/* Referral rows would go here */}</tbody>
                        </table>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-6">
                      <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <h3 className="text-lg font-medium mb-2">No referrals yet</h3>
                      <p className="text-muted-foreground max-w-md mx-auto">
                        Share your referral link with friends to start earning. You'll receive 20% of their investment.
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </div>
        </div>
      </main>
    </div>
  )
}
