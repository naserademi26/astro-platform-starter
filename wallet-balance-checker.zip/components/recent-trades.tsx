"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"

// Different trade data for each wallet
const initialTradeData = {
  agon: [
    {
      id: 1,
      pair: "BTC/USDT",
      type: "long",
      amount: 12500.45,
      profit: 2.48,
      date: "2025-05-20",
      time: "14:32:21",
    },
    {
      id: 2,
      pair: "ETH/USDT",
      type: "short",
      amount: 8750.32,
      profit: 3.35,
      date: "2025-05-20",
      time: "11:45:09",
    },
    {
      id: 3,
      pair: "SOL/USDT",
      type: "long",
      amount: 6245.67,
      profit: -2.33,
      date: "2025-05-19",
      time: "22:15:33",
    },
    {
      id: 4,
      pair: "PEPE/USDT",
      type: "long",
      amount: 15000.0,
      profit: 7.24,
      date: "2025-05-19",
      time: "18:04:52",
    },
    {
      id: 5,
      pair: "BNB/USDT",
      type: "short",
      amount: 5025.44,
      profit: 2.22,
      date: "2025-05-19",
      time: "15:22:47",
    },
  ],
  nexhaip: [
    {
      id: 1,
      pair: "PEPE/USDT",
      type: "long",
      amount: 12500.0,
      profit: 8.04,
      date: "2025-05-20",
      time: "16:12:33",
    },
    {
      id: 2,
      pair: "SHIB/USDT",
      type: "long",
      amount: 15000.0,
      profit: 3.03,
      date: "2025-05-20",
      time: "10:23:45",
    },
    {
      id: 3,
      pair: "DOGE/USDT",
      type: "short",
      amount: 3000.0,
      profit: 2.38,
      date: "2025-05-19",
      time: "21:05:17",
    },
    {
      id: 4,
      pair: "FLOKI/USDT",
      type: "long",
      amount: 8445.88,
      profit: -2.65,
      date: "2025-05-19",
      time: "14:45:22",
    },
    {
      id: 5,
      pair: "ETH/USDT",
      type: "long",
      amount: 5000.0,
      profit: 1.66,
      date: "2025-05-18",
      time: "09:34:11",
    },
  ],
  cryptowhale: [
    {
      id: 1,
      pair: "BTC/USDT",
      type: "long",
      amount: 50000.0,
      profit: 3.66,
      date: "2025-05-20",
      time: "18:23:45",
    },
    {
      id: 2,
      pair: "ETH/USDT",
      type: "long",
      amount: 35000.0,
      profit: 5.08,
      date: "2025-05-20",
      time: "15:12:34",
    },
    {
      id: 3,
      pair: "SOL/USDT",
      type: "short",
      amount: 25000.0,
      profit: 4.63,
      date: "2025-05-19",
      time: "23:45:12",
    },
    {
      id: 4,
      pair: "BONK/USDT",
      type: "long",
      amount: 45000.0,
      profit: 9.52,
      date: "2025-05-19",
      time: "20:34:56",
    },
    {
      id: 5,
      pair: "WIF/USDT",
      type: "short",
      amount: 35789.45,
      profit: 6.32,
      date: "2025-05-18",
      time: "12:23:45",
    },
  ],
  tradingmaster: [
    {
      id: 1,
      pair: "BTC/USDT",
      type: "short",
      amount: 25000.0,
      profit: 1.96,
      date: "2025-05-20",
      time: "17:45:23",
    },
    {
      id: 2,
      pair: "ETH/USDT",
      type: "long",
      amount: 20000.0,
      profit: 1.99,
      date: "2025-05-20",
      time: "13:23:45",
    },
    {
      id: 3,
      pair: "MATIC/USDT",
      type: "long",
      amount: 15000.0,
      profit: 4.31,
      date: "2025-05-19",
      time: "19:34:56",
    },
    {
      id: 4,
      pair: "LINK/USDT",
      type: "short",
      amount: 12500.0,
      profit: 3.02,
      date: "2025-05-19",
      time: "16:23:45",
    },
    {
      id: 5,
      pair: "XRP/USDT",
      type: "long",
      amount: 10000.0,
      profit: -2.83,
      date: "2025-05-18",
      time: "11:12:34",
    },
  ],
  selami: [
    {
      id: 1,
      pair: "DOGE/USDT",
      type: "long",
      amount: 5000.0,
      profit: 4.25,
      date: "2025-05-20",
      time: "15:45:23",
    },
    {
      id: 2,
      pair: "SHIB/USDT",
      type: "long",
      amount: 6500.0,
      profit: 2.87,
      date: "2025-05-20",
      time: "12:34:56",
    },
    {
      id: 3,
      pair: "PEPE/USDT",
      type: "long",
      amount: 7800.0,
      profit: 3.45,
      date: "2025-05-19",
      time: "20:12:34",
    },
    {
      id: 4,
      pair: "FLOKI/USDT",
      type: "short",
      amount: 4500.0,
      profit: -3.12,
      date: "2025-05-19",
      time: "17:23:45",
    },
    {
      id: 5,
      pair: "BTC/USDT",
      type: "long",
      amount: 3200.0,
      profit: 1.98,
      date: "2025-05-18",
      time: "10:45:23",
    },
  ],
  milazim: [
    {
      id: 1,
      pair: "BTC/USDT",
      type: "long",
      amount: 15000.0,
      profit: 3.75,
      date: "2025-05-20",
      time: "16:45:23",
    },
    {
      id: 2,
      pair: "ETH/USDT",
      type: "long",
      amount: 12500.0,
      profit: 4.12,
      date: "2025-05-20",
      time: "13:22:45",
    },
    {
      id: 3,
      pair: "SOL/USDT",
      type: "long",
      amount: 10000.0,
      profit: 6.45,
      date: "2025-05-19",
      time: "21:34:12",
    },
    {
      id: 4,
      pair: "AVAX/USDT",
      type: "short",
      amount: 8500.0,
      profit: -2.85,
      date: "2025-05-19",
      time: "18:12:34",
    },
    {
      id: 5,
      pair: "DOGE/USDT",
      type: "long",
      amount: 6800.0,
      profit: 2.65,
      date: "2025-05-18",
      time: "11:45:23",
    },
  ],
}

export function RecentTrades({
  walletName = "agon",
  isMobile = false,
  newTrade = null,
  currentDate = new Date(2025, 4, 20),
}: {
  walletName?: string
  isMobile?: boolean
  newTrade?: any
  currentDate?: Date
}) {
  const [trades, setTrades] = useState(initialTradeData[walletName] || initialTradeData["agon"])

  // Update trades when wallet changes
  useEffect(() => {
    setTrades(initialTradeData[walletName] || initialTradeData["agon"])
  }, [walletName])

  // Add new trade when it comes in
  useEffect(() => {
    if (newTrade) {
      setTrades((prevTrades) => {
        // Add new trade at the beginning and keep only the latest 5
        const updatedTrades = [newTrade, ...prevTrades.slice(0, 4)]
        return updatedTrades
      })
    }
  }, [newTrade])

  // Calculate total profit/loss
  const totalProfitLoss = trades.reduce((sum, trade) => {
    const profitAmount = (trade.amount * trade.profit) / 100
    return sum + profitAmount
  }, 0)

  // Mobile card view for trades
  if (isMobile) {
    return (
      <Card>
        <CardHeader className="pb-2 pt-4 px-4">
          <CardTitle className="text-base">Recent Trades</CardTitle>
          <CardDescription className="text-xs">Last 5 trades with profit/loss</CardDescription>
        </CardHeader>
        <CardContent className="px-4 py-2">
          <div className="space-y-4">
            {trades.map((trade) => (
              <div key={trade.id} className="border rounded-md p-3">
                <div className="flex justify-between items-center mb-2">
                  <div className="font-medium">{trade.pair}</div>
                  <Badge variant={trade.type === "long" ? "default" : "secondary"} className="text-xs">
                    {trade.type.toUpperCase()}
                  </Badge>
                </div>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <div className="text-muted-foreground text-xs">Amount</div>
                    <div>
                      {trade.amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}{" "}
                      USDT
                    </div>
                  </div>
                  <div>
                    <div className="text-muted-foreground text-xs">Profit/Loss</div>
                    <div className={trade.profit >= 0 ? "text-green-600" : "text-red-600"}>
                      {trade.profit >= 0 ? "+" : ""}
                      {trade.profit}% (
                      {((trade.amount * trade.profit) / 100).toLocaleString(undefined, {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2,
                      })}{" "}
                      USDT)
                    </div>
                  </div>
                  <div>
                    <div className="text-muted-foreground text-xs">Date</div>
                    <div>{trade.date}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground text-xs">Time</div>
                    <div>{trade.time}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 flex justify-between items-center border-t pt-3">
            <div className="text-xs text-muted-foreground">Total trades: {trades.length}</div>
            <div className={`font-medium text-sm ${totalProfitLoss >= 0 ? "text-green-600" : "text-red-600"}`}>
              Total P/L: {totalProfitLoss >= 0 ? "+" : ""}
              {totalProfitLoss.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USDT
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  // Desktop table view for trades
  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Trades</CardTitle>
        <CardDescription>Last 5 trades with profit/loss</CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Trading Pair</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Amount (USDT)</TableHead>
              <TableHead>Profit/Loss</TableHead>
              <TableHead>Date & Time</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {trades.map((trade) => (
              <TableRow key={trade.id}>
                <TableCell className="font-medium">{trade.pair}</TableCell>
                <TableCell>
                  <Badge variant={trade.type === "long" ? "default" : "secondary"}>{trade.type.toUpperCase()}</Badge>
                </TableCell>
                <TableCell>
                  {trade.amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </TableCell>
                <TableCell className={trade.profit >= 0 ? "text-green-600" : "text-red-600"}>
                  <div className="flex flex-col">
                    <span>
                      {trade.profit >= 0 ? "+" : ""}
                      {trade.profit}%
                    </span>
                    <span className="text-xs">
                      {trade.profit >= 0 ? "+" : ""}
                      {((trade.amount * trade.profit) / 100).toLocaleString(undefined, {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2,
                      })}{" "}
                      USDT
                    </span>
                  </div>
                </TableCell>
                <TableCell>
                  {trade.date} {trade.time}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        <div className="mt-4 flex justify-between items-center">
          <div className="text-sm text-muted-foreground">Total trades: {trades.length}</div>
          <div className={`font-medium ${totalProfitLoss >= 0 ? "text-green-600" : "text-red-600"}`}>
            Total P/L: {totalProfitLoss >= 0 ? "+" : ""}
            {totalProfitLoss.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USDT
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
