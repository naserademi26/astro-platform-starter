"use client"

import { Line, LineChart, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartContainer, ChartTooltipContent } from "@/components/ui/chart"

// Format date as YYYY-MM-DD
const formatDate = (date: Date) => {
  return date.toISOString().split("T")[0]
}

// Generate realistic trading data for the last 3 months
const generateBalanceData = (walletName: string, currentDate: Date) => {
  const data = []
  const startDate = new Date(currentDate)
  startDate.setMonth(startDate.getMonth() - 3)

  // Start with initial balance based on wallet
  let balance = 42000
  let finalBalance = 47521.88
  let volatility = 1.5
  let bigWinDays = [15, 40, 65]

  // Customize parameters based on wallet name
  if (walletName === "nexhaip") {
    balance = 36000
    finalBalance = 38945.88
    volatility = 1.2
    bigWinDays = [12, 35, 70]
  } else if (walletName === "cryptowhale") {
    balance = 128000
    finalBalance = 156789.45
    volatility = 2.0
    bigWinDays = [10, 30, 60]
  } else if (walletName === "tradingmaster") {
    balance = 73500
    finalBalance = 85432.67
    volatility = 1.8
    bigWinDays = [20, 45, 75]
  } else if (walletName === "selami") {
    balance = 21500
    finalBalance = 22986.77
    volatility = 1.0
    bigWinDays = [25, 50, 80]
  } else if (walletName === "milazim") {
    balance = 45800
    finalBalance = 52843.55
    volatility = 1.6
    bigWinDays = [18, 42, 68]
  }

  // Generate daily data for 3 months (90 days)
  for (let i = 0; i < 90; i++) {
    const date = new Date(startDate)
    date.setDate(date.getDate() + i)

    // Create realistic fluctuations
    // More volatility on some days, steady growth on others
    const changePercent = (Math.random() * 2 * volatility - volatility) / 100 // Between -volatility% and +volatility%

    // Add some significant events
    if (i === bigWinDays[0]) balance *= 1.08 // Big win
    if (i === bigWinDays[1]) balance *= 0.93 // Market correction
    if (i === bigWinDays[2]) balance *= 1.12 // Another big win

    // Daily fluctuation
    balance = balance * (1 + changePercent)

    data.push({
      date: formatDate(date),
      balance: Math.round(balance * 100) / 100,
    })
  }

  // Ensure final balance matches the expected value
  data[data.length - 1].balance = finalBalance

  return data
}

export function BalanceChart({
  walletName = "agon",
  isMobile = false,
  currentDate = new Date(2025, 4, 20),
}: {
  walletName?: string
  isMobile?: boolean
  currentDate?: Date
}) {
  const balanceData = generateBalanceData(walletName, currentDate)

  // For mobile, use fewer data points to avoid overcrowding
  const mobileData = isMobile
    ? balanceData.filter((_, index) => index % 3 === 0 || index === balanceData.length - 1)
    : balanceData

  // Calculate date range for display
  const startDate = new Date(currentDate)
  startDate.setMonth(startDate.getMonth() - 3)
  const startDateStr = startDate.toLocaleDateString("en-US", { month: "short", day: "numeric" })
  const endDateStr = currentDate.toLocaleDateString("en-US", { month: "short", day: "numeric" })

  return (
    <Card>
      <CardHeader className={isMobile ? "pb-2 pt-4 px-4" : undefined}>
        <CardTitle className={isMobile ? "text-base" : undefined}>Balance History</CardTitle>
        <CardDescription className={isMobile ? "text-xs" : undefined}>
          {startDateStr} - {endDateStr}
        </CardDescription>
      </CardHeader>
      <CardContent className={isMobile ? "px-1 pt-0" : undefined}>
        <ChartContainer
          config={{
            balance: {
              label: "Balance",
              color: "hsl(var(--chart-1))",
            },
          }}
          className={isMobile ? "h-[200px]" : "h-[300px]"}
        >
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={mobileData}
              margin={isMobile ? { top: 5, right: 10, left: 0, bottom: 5 } : { top: 5, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
              <XAxis
                dataKey="date"
                tickFormatter={(date) => {
                  const d = new Date(date)
                  return `${d.getMonth() + 1}/${d.getDate()}`
                }}
                tick={{ fontSize: isMobile ? 10 : 12 }}
                tickMargin={isMobile ? 5 : 10}
                interval={isMobile ? "preserveStartEnd" : 0}
              />
              <YAxis
                tickFormatter={(value) => (isMobile ? `$${Math.round(value / 1000)}k` : `$${value.toLocaleString()}`)}
                tick={{ fontSize: isMobile ? 10 : 12 }}
                width={isMobile ? 40 : 60}
                domain={["dataMin - 2000", "dataMax + 2000"]}
              />
              <Tooltip
                content={<ChartTooltipContent />}
                formatter={(value: number) => [`$${value.toLocaleString()}`, "Balance"]}
                labelFormatter={(label) => {
                  const date = new Date(label)
                  return date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })
                }}
              />
              <Line
                type="monotone"
                dataKey="balance"
                stroke="var(--color-balance)"
                strokeWidth={2}
                dot={false}
                activeDot={{ r: isMobile ? 4 : 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </ChartContainer>
      </CardContent>
    </Card>
  )
}
