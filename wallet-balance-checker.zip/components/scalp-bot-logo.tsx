import { TrendingUp } from "lucide-react"

export function ScalpBotLogo({ className = "" }: { className?: string }) {
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <div className="bg-gradient-to-r from-blue-600 to-cyan-500 p-2 rounded-lg">
        <TrendingUp className="h-5 w-5 text-white" />
      </div>
      <div className="font-bold text-xl">
        <span className="text-blue-600">Scalp</span>
        <span className="text-gray-800">Trading</span>
        <span className="text-cyan-500">BOT</span>
      </div>
    </div>
  )
}
