import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"

// Different profit data for each wallet
const profitData = {
  agon: [
    { pair: "BTC/USDT", profit: 1250.45, percentage: 26 },
    { pair: "ETH/USDT", profit: 950.32, percentage: 20 },
    { pair: "PEPE/USDT", profit: 1086.0, percentage: 23 },
    { pair: "SOL/USDT", profit: -145.67, percentage: -3 },
    { pair: "BNB/USDT", profit: 850.44, percentage: 18 },
    { pair: "Others", profit: 750.21, percentage: 16 },
  ],
  nexhaip: [
    { pair: "PEPE/USDT", profit: 1005.0, percentage: 31 },
    { pair: "SHIB/USDT", profit: 454.5, percentage: 14 },
    { pair: "DOGE/USDT", profit: 714.0, percentage: 22 },
    { pair: "FLOKI/USDT", profit: -223.82, percentage: -7 },
    { pair: "ETH/USDT", profit: 830.0, percentage: 25 },
    { pair: "Others", profit: 500.2, percentage: 15 },
  ],
  cryptowhale: [
    { pair: "BTC/USDT", profit: 1830.0, percentage: 18 },
    { pair: "ETH/USDT", profit: 1778.0, percentage: 17 },
    { pair: "SOL/USDT", profit: 1157.5, percentage: 11 },
    { pair: "BONK/USDT", profit: 4284.0, percentage: 41 },
    { pair: "WIF/USDT", profit: 2261.89, percentage: 22 },
    { pair: "Others", profit: -950.45, percentage: -9 },
  ],
  tradingmaster: [
    { pair: "BTC/USDT", profit: 490.0, percentage: 24 },
    { pair: "ETH/USDT", profit: 398.0, percentage: 19 },
    { pair: "MATIC/USDT", profit: 646.5, percentage: 31 },
    { pair: "LINK/USDT", profit: 377.5, percentage: 18 },
    { pair: "XRP/USDT", profit: -283.0, percentage: -14 },
    { pair: "Others", profit: 450.25, percentage: 22 },
  ],
  selami: [
    { pair: "DOGE/USDT", profit: 356.78, percentage: 24 },
    { pair: "SHIB/USDT", profit: 289.45, percentage: 20 },
    { pair: "PEPE/USDT", profit: 412.32, percentage: 28 },
    { pair: "FLOKI/USDT", profit: -178.56, percentage: -12 },
    { pair: "BTC/USDT", profit: 245.67, percentage: 17 },
    { pair: "Others", profit: 165.34, percentage: 11 },
  ],
  milazim: [
    { pair: "BTC/USDT", profit: 1450.67, percentage: 22 },
    { pair: "ETH/USDT", profit: 1250.45, percentage: 19 },
    { pair: "SOL/USDT", profit: 1680.32, percentage: 25 },
    { pair: "DOGE/USDT", profit: 850.78, percentage: 13 },
    { pair: "AVAX/USDT", profit: -320.45, percentage: -5 },
    { pair: "Others", profit: 1750.23, percentage: 26 },
  ],
}

export function ProfitSummary({ walletName = "agon", isMobile = false }: { walletName?: string; isMobile?: boolean }) {
  const profits = profitData[walletName] || profitData["agon"]

  // Calculate total profit (excluding negative values for progress bar calculation)
  const totalPositiveProfit = profits.reduce((sum, item) => sum + (item.profit > 0 ? item.profit : 0), 0)

  return (
    <Card>
      <CardHeader className={isMobile ? "pb-2 pt-4 px-4" : undefined}>
        <CardTitle className={isMobile ? "text-base" : undefined}>Profit Distribution</CardTitle>
        <CardDescription className={isMobile ? "text-xs" : undefined}>Profit breakdown by trading pair</CardDescription>
      </CardHeader>
      <CardContent className={isMobile ? "px-4 py-2" : undefined}>
        <div className="space-y-3 md:space-y-4">
          {profits.map((item) => (
            <div key={item.pair} className="space-y-1">
              <div className="flex items-center justify-between">
                <div className={`font-medium ${isMobile ? "text-sm" : ""}`}>{item.pair}</div>
                <div className={`${item.profit >= 0 ? "text-green-600" : "text-red-600"} ${isMobile ? "text-sm" : ""}`}>
                  {item.profit >= 0 ? "+" : ""}
                  {item.profit.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USDT
                </div>
              </div>
              {item.profit > 0 && <Progress value={(item.profit / totalPositiveProfit) * 100} className="h-2" />}
              {item.profit < 0 && <Progress value={0} className="h-2 bg-red-100" />}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
