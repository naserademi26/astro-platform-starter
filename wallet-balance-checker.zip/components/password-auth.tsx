"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { AlertCircle, Eye, EyeOff, Lock } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

// Wallet passwords
const WALLET_PASSWORDS = {
  agon: "Agoni1244;",
  nexhaip: "Nexhi1244;",
  selami: "Sela1244;",
  milazim: "Arniti1244;",
  cryptowhale: "Crypto1244;",
  tradingmaster: "Trading1244;",
}

export function PasswordAuth({
  walletName,
  onSuccess,
  onCancel,
}: {
  walletName: string
  onSuccess: () => void
  onCancel: () => void
}) {
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [attempts, setAttempts] = useState(0)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Check if wallet exists in our password database
    if (!WALLET_PASSWORDS[walletName.toLowerCase()]) {
      setError("Unknown wallet. Please check the wallet name.")
      return
    }

    // Validate password
    if (password === WALLET_PASSWORDS[walletName.toLowerCase()]) {
      onSuccess()
    } else {
      setAttempts(attempts + 1)
      if (attempts >= 2) {
        setError("Too many failed attempts. Please try again later.")
      } else {
        setError(`Incorrect password. ${3 - attempts - 1} attempts remaining.`)
      }
      setPassword("")
    }
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg max-w-md w-full">
      <div className="flex flex-col items-center mb-6">
        <div className="bg-blue-100 p-3 rounded-full mb-4">
          <Lock className="h-8 w-8 text-blue-600" />
        </div>
        <h2 className="text-xl font-bold mb-1">Password Required</h2>
        <p className="text-center text-muted-foreground text-sm">Please enter the password for wallet "{walletName}"</p>
      </div>

      {error && (
        <Alert variant="destructive" className="mb-4">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <form onSubmit={handleSubmit}>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <div className="relative">
              <Input
                id="password"
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="pr-10"
                placeholder="Enter wallet password"
                disabled={attempts >= 3}
                autoFocus
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                tabIndex={-1}
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>

          <div className="flex gap-3">
            <Button type="button" variant="outline" className="flex-1" onClick={onCancel}>
              Cancel
            </Button>
            <Button type="submit" className="flex-1" disabled={!password || attempts >= 3}>
              Login
            </Button>
          </div>
        </div>
      </form>
    </div>
  )
}
