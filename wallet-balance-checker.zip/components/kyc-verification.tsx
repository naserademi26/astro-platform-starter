"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { AlertCircle, CheckCircle2, Upload, User, FileText, Calendar, MapPin } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"

export function KycVerification({
  onComplete,
  onCancel,
}: {
  onComplete: () => void
  onCancel: () => void
}) {
  const [step, setStep] = useState(1)
  const [progress, setProgress] = useState(25)
  const [personalInfo, setPersonalInfo] = useState({
    firstName: "",
    lastName: "",
    dateOfBirth: "",
    nationality: "",
  })
  const [addressInfo, setAddressInfo] = useState({
    address1: "",
    address2: "",
    city: "",
    postalCode: "",
    country: "",
  })
  const [idDocument, setIdDocument] = useState<File | null>(null)
  const [addressDocument, setAddressDocument] = useState<File | null>(null)
  const [selfieDocument, setSelfieDocument] = useState<File | null>(null)
  const [termsAccepted, setTermsAccepted] = useState(false)

  const handleNext = () => {
    const nextStep = step + 1
    setStep(nextStep)
    setProgress(nextStep * 25)
  }

  const handlePrevious = () => {
    const prevStep = step - 1
    setStep(prevStep)
    setProgress(prevStep * 25)
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, type: "id" | "address" | "selfie") => {
    if (e.target.files && e.target.files[0]) {
      if (type === "id") {
        setIdDocument(e.target.files[0])
      } else if (type === "address") {
        setAddressDocument(e.target.files[0])
      } else {
        setSelfieDocument(e.target.files[0])
      }
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Always succeed for demo purposes
    onComplete()
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg max-w-2xl w-full">
      <div className="mb-6">
        <h2 className="text-xl font-bold mb-2">KYC Verification</h2>
        <p className="text-muted-foreground">
          Complete the verification process to increase your withdrawal limits and enhance account security.
        </p>
        <Progress value={progress} className="h-2 mt-4" />
        <div className="flex justify-between text-xs text-muted-foreground mt-1">
          <span>Personal Info</span>
          <span>Address</span>
          <span>Documents</span>
          <span>Confirmation</span>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <Alert className="mb-4 bg-amber-50 border-amber-200">
          <AlertCircle className="h-4 w-4 text-amber-600" />
          <AlertDescription className="text-amber-700">
            <span className="font-medium">Demo Mode:</span> All fields are optional for this demo. You can proceed
            through all steps.
          </AlertDescription>
        </Alert>
        {/* Step 1: Personal Information */}
        {step === 1 && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 mb-4">
              <User className="h-5 w-5 text-blue-600" />
              <h3 className="text-lg font-medium">Personal Information</h3>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="firstName">First Name</Label>
                <Input
                  id="firstName"
                  value={personalInfo.firstName}
                  onChange={(e) => setPersonalInfo({ ...personalInfo, firstName: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="lastName">Last Name</Label>
                <Input
                  id="lastName"
                  value={personalInfo.lastName}
                  onChange={(e) => setPersonalInfo({ ...personalInfo, lastName: e.target.value })}
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="dateOfBirth">Date of Birth</Label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="dateOfBirth"
                    type="date"
                    className="pl-10"
                    value={personalInfo.dateOfBirth}
                    onChange={(e) => setPersonalInfo({ ...personalInfo, dateOfBirth: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="nationality">Nationality</Label>
                <Select
                  value={personalInfo.nationality}
                  onValueChange={(value) => setPersonalInfo({ ...personalInfo, nationality: value })}
                >
                  <SelectTrigger id="nationality">
                    <SelectValue placeholder="Select nationality" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="us">United States</SelectItem>
                    <SelectItem value="uk">United Kingdom</SelectItem>
                    <SelectItem value="ca">Canada</SelectItem>
                    <SelectItem value="au">Australia</SelectItem>
                    <SelectItem value="de">Germany</SelectItem>
                    <SelectItem value="fr">France</SelectItem>
                    <SelectItem value="jp">Japan</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Alert className="bg-blue-50 border-blue-200">
              <AlertCircle className="h-4 w-4 text-blue-600" />
              <AlertDescription className="text-blue-700">
                Please ensure your name matches your identification documents exactly.
              </AlertDescription>
            </Alert>
          </div>
        )}

        {/* Step 2: Address Information */}
        {step === 2 && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 mb-4">
              <MapPin className="h-5 w-5 text-blue-600" />
              <h3 className="text-lg font-medium">Address Information</h3>
            </div>

            <div className="space-y-2">
              <Label htmlFor="address1">Address Line 1</Label>
              <Input
                id="address1"
                value={addressInfo.address1}
                onChange={(e) => setAddressInfo({ ...addressInfo, address1: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="address2">Address Line 2 (Optional)</Label>
              <Input
                id="address2"
                value={addressInfo.address2}
                onChange={(e) => setAddressInfo({ ...addressInfo, address2: e.target.value })}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="city">City</Label>
                <Input
                  id="city"
                  value={addressInfo.city}
                  onChange={(e) => setAddressInfo({ ...addressInfo, city: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="postalCode">Postal Code</Label>
                <Input
                  id="postalCode"
                  value={addressInfo.postalCode}
                  onChange={(e) => setAddressInfo({ ...addressInfo, postalCode: e.target.value })}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="country">Country</Label>
              <Select
                value={addressInfo.country}
                onValueChange={(value) => setAddressInfo({ ...addressInfo, country: value })}
              >
                <SelectTrigger id="country">
                  <SelectValue placeholder="Select country" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="us">United States</SelectItem>
                  <SelectItem value="uk">United Kingdom</SelectItem>
                  <SelectItem value="ca">Canada</SelectItem>
                  <SelectItem value="au">Australia</SelectItem>
                  <SelectItem value="de">Germany</SelectItem>
                  <SelectItem value="fr">France</SelectItem>
                  <SelectItem value="jp">Japan</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Alert className="bg-blue-50 border-blue-200">
              <AlertCircle className="h-4 w-4 text-blue-600" />
              <AlertDescription className="text-blue-700">
                Your address will be verified against the proof of address document you provide.
              </AlertDescription>
            </Alert>
          </div>
        )}

        {/* Step 3: Document Upload */}
        {step === 3 && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 mb-4">
              <FileText className="h-5 w-5 text-blue-600" />
              <h3 className="text-lg font-medium">Document Verification</h3>
            </div>

            <div className="space-y-2">
              <Label htmlFor="idDocument">Government-Issued ID</Label>
              <div className="border-2 border-dashed rounded-md p-4 flex flex-col items-center justify-center">
                <Upload className="h-8 w-8 text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground mb-2">Upload passport, driver's license, or ID card</p>
                <Input
                  id="idDocument"
                  type="file"
                  className="hidden"
                  accept="image/*,.pdf"
                  onChange={(e) => handleFileChange(e, "id")}
                />
                <Button
                  variant="outline"
                  onClick={() => document.getElementById("idDocument")?.click()}
                  className="mt-2"
                >
                  Select File
                </Button>
                {idDocument && (
                  <div className="mt-4 flex items-center gap-2 text-sm text-green-600">
                    <CheckCircle2 className="h-4 w-4" />
                    <span>{idDocument.name}</span>
                  </div>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="addressDocument">Proof of Address</Label>
              <div className="border-2 border-dashed rounded-md p-4 flex flex-col items-center justify-center">
                <Upload className="h-8 w-8 text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground mb-2">
                  Upload utility bill or bank statement (less than 3 months old)
                </p>
                <Input
                  id="addressDocument"
                  type="file"
                  className="hidden"
                  accept="image/*,.pdf"
                  onChange={(e) => handleFileChange(e, "address")}
                />
                <Button
                  variant="outline"
                  onClick={() => document.getElementById("addressDocument")?.click()}
                  className="mt-2"
                >
                  Select File
                </Button>
                {addressDocument && (
                  <div className="mt-4 flex items-center gap-2 text-sm text-green-600">
                    <CheckCircle2 className="h-4 w-4" />
                    <span>{addressDocument.name}</span>
                  </div>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="selfieDocument">Selfie with ID</Label>
              <div className="border-2 border-dashed rounded-md p-4 flex flex-col items-center justify-center">
                <Upload className="h-8 w-8 text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground mb-2">Upload a photo of yourself holding your ID</p>
                <Input
                  id="selfieDocument"
                  type="file"
                  className="hidden"
                  accept="image/*"
                  onChange={(e) => handleFileChange(e, "selfie")}
                />
                <Button
                  variant="outline"
                  onClick={() => document.getElementById("selfieDocument")?.click()}
                  className="mt-2"
                >
                  Select File
                </Button>
                {selfieDocument && (
                  <div className="mt-4 flex items-center gap-2 text-sm text-green-600">
                    <CheckCircle2 className="h-4 w-4" />
                    <span>{selfieDocument.name}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Step 4: Confirmation */}
        {step === 4 && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 mb-4">
              <CheckCircle2 className="h-5 w-5 text-blue-600" />
              <h3 className="text-lg font-medium">Confirmation</h3>
            </div>

            <Alert className="bg-green-50 border-green-200">
              <CheckCircle2 className="h-4 w-4 text-green-600" />
              <AlertTitle className="text-green-800">Almost Done!</AlertTitle>
              <AlertDescription className="text-green-700">
                Please review your information before submitting. Once submitted, your KYC verification will be
                processed within 24-48 hours.
              </AlertDescription>
            </Alert>

            <div className="border rounded-md p-4 space-y-4">
              <div>
                <h4 className="font-medium mb-2">Personal Information</h4>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <span className="text-muted-foreground">Name:</span>
                    <p>
                      {personalInfo.firstName} {personalInfo.lastName}
                    </p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Date of Birth:</span>
                    <p>{personalInfo.dateOfBirth}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Nationality:</span>
                    <p>{personalInfo.nationality}</p>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-medium mb-2">Address</h4>
                <div className="text-sm">
                  <p>{addressInfo.address1}</p>
                  {addressInfo.address2 && <p>{addressInfo.address2}</p>}
                  <p>
                    {addressInfo.city}, {addressInfo.postalCode}
                  </p>
                  <p>{addressInfo.country}</p>
                </div>
              </div>

              <div>
                <h4 className="font-medium mb-2">Documents</h4>
                <div className="grid grid-cols-3 gap-2 text-sm">
                  <div>
                    <span className="text-muted-foreground">ID Document:</span>
                    <p className="text-green-600">{idDocument ? "Uploaded" : "Not uploaded"}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Proof of Address:</span>
                    <p className="text-green-600">{addressDocument ? "Uploaded" : "Not uploaded"}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Selfie with ID:</span>
                    <p className="text-green-600">{selfieDocument ? "Uploaded" : "Not uploaded"}</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-start space-x-2">
              <Checkbox
                id="terms"
                checked={termsAccepted}
                onCheckedChange={(checked) => setTermsAccepted(checked === true)}
              />
              <div className="grid gap-1.5 leading-none">
                <Label
                  htmlFor="terms"
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                  I confirm that all information provided is accurate and authentic
                </Label>
                <p className="text-sm text-muted-foreground">
                  By submitting this form, you agree to our terms of service and privacy policy.
                </p>
              </div>
            </div>
          </div>
        )}

        <div className="flex justify-between mt-6">
          {step > 1 ? (
            <Button type="button" variant="outline" onClick={handlePrevious}>
              Previous
            </Button>
          ) : (
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancel
            </Button>
          )}

          {step < 4 ? (
            <Button
              type="button"
              onClick={handleNext}
              disabled={false} // Remove validation requirements for demo
            >
              Next
            </Button>
          ) : (
            <Button type="submit" disabled={!termsAccepted}>
              Submit Verification
            </Button>
          )}
        </div>
      </form>
    </div>
  )
}
