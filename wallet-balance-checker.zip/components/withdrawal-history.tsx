"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, Calendar, Download, ExternalLink } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Mock withdrawal history data
const MOCK_WITHDRAWALS = [
  {
    id: "W-001",
    date: "2025-05-20",
    amount: 1500,
    method: "TON Network",
    address: "UQDFih7...",
    status: "completed",
    txId: "0x71C7656EC7ab88b098defB751B7401B5f6d8976F",
  },
  {
    id: "W-002",
    date: "2025-05-15",
    amount: 2500,
    method: "Bitcoin",
    address: "bc1qxy...",
    status: "processing",
    txId: "",
  },
  {
    id: "W-003",
    date: "2025-05-10",
    amount: 500,
    method: "Ethereum",
    address: "0x71C7...",
    status: "completed",
    txId: "0x71C7656EC7ab88b098defB751B7401B5f6d8976F",
  },
  {
    id: "W-004",
    date: "2025-05-05",
    amount: 1000,
    method: "USDT",
    address: "0x8F32...",
    status: "rejected",
    txId: "",
  },
]

// Status badge component
function StatusBadge({ status }: { status: string }) {
  const variants = {
    completed: "bg-green-100 text-green-800 border-green-200",
    processing: "bg-yellow-100 text-yellow-800 border-yellow-200",
    pending: "bg-blue-100 text-blue-800 border-blue-200",
    rejected: "bg-red-100 text-red-800 border-red-200",
  }

  return (
    <Badge className={`${variants[status]} font-medium`} variant="outline">
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </Badge>
  )
}

export function WithdrawalHistory({ isMobile = false }: { isMobile?: boolean }) {
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")

  // Filter withdrawals based on search query and status filter
  const filteredWithdrawals = MOCK_WITHDRAWALS.filter((withdrawal) => {
    const matchesSearch =
      withdrawal.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      withdrawal.method.toLowerCase().includes(searchQuery.toLowerCase()) ||
      withdrawal.address.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesStatus = statusFilter === "all" || withdrawal.status === statusFilter

    return matchesSearch && matchesStatus
  })

  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" })
  }

  // Mobile card view
  if (isMobile) {
    return (
      <Card>
        <CardHeader className="pb-2 pt-4 px-4">
          <CardTitle className="text-base">Withdrawal History</CardTitle>
          <CardDescription className="text-xs">View your past withdrawal requests</CardDescription>
          <div className="mt-2 space-y-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search withdrawals..."
                className="pl-9 text-sm"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="text-sm">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="processing">Processing</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent className="px-4 py-2">
          <div className="space-y-3">
            {filteredWithdrawals.length > 0 ? (
              filteredWithdrawals.map((withdrawal) => (
                <div key={withdrawal.id} className="border rounded-md p-3">
                  <div className="flex justify-between items-center mb-2">
                    <div className="font-medium text-sm">{withdrawal.id}</div>
                    <StatusBadge status={withdrawal.status} />
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <div className="text-muted-foreground">Date</div>
                      <div className="flex items-center">
                        <Calendar className="h-3 w-3 mr-1" />
                        {formatDate(withdrawal.date)}
                      </div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Amount</div>
                      <div className="font-medium">{withdrawal.amount.toLocaleString()} USDT</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Method</div>
                      <div>{withdrawal.method}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Address</div>
                      <div className="truncate">{withdrawal.address}</div>
                    </div>
                  </div>
                  {withdrawal.txId && (
                    <div className="mt-2 pt-2 border-t text-xs">
                      <div className="text-muted-foreground">Transaction ID</div>
                      <div className="flex items-center justify-between">
                        <div className="truncate max-w-[150px]">{withdrawal.txId}</div>
                        <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                          <ExternalLink className="h-3 w-3" />
                          <span className="sr-only">View Transaction</span>
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              ))
            ) : (
              <div className="text-center py-6 text-muted-foreground text-sm">No withdrawal history found</div>
            )}
          </div>
        </CardContent>
      </Card>
    )
  }

  // Desktop table view
  return (
    <Card>
      <CardHeader>
        <CardTitle>Withdrawal History</CardTitle>
        <CardDescription>View your past withdrawal requests and their status</CardDescription>
        <div className="flex flex-col sm:flex-row gap-2 mt-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by ID, method or address..."
              className="pl-9"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="processing">Processing</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="icon">
            <Download className="h-4 w-4" />
            <span className="sr-only">Download CSV</span>
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {filteredWithdrawals.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Method</TableHead>
                <TableHead>Address</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Transaction ID</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredWithdrawals.map((withdrawal) => (
                <TableRow key={withdrawal.id}>
                  <TableCell className="font-medium">{withdrawal.id}</TableCell>
                  <TableCell>{formatDate(withdrawal.date)}</TableCell>
                  <TableCell>{withdrawal.amount.toLocaleString()} USDT</TableCell>
                  <TableCell>{withdrawal.method}</TableCell>
                  <TableCell className="max-w-[120px] truncate">{withdrawal.address}</TableCell>
                  <TableCell>
                    <StatusBadge status={withdrawal.status} />
                  </TableCell>
                  <TableCell>
                    {withdrawal.txId ? (
                      <div className="flex items-center">
                        <span className="max-w-[120px] truncate">{withdrawal.txId}</span>
                        <Button variant="ghost" size="sm" className="ml-2 h-8 w-8 p-0">
                          <ExternalLink className="h-4 w-4" />
                          <span className="sr-only">View Transaction</span>
                        </Button>
                      </div>
                    ) : (
                      <span className="text-muted-foreground">-</span>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <div className="text-center py-12">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-gray-100 mb-4">
              <Download className="h-6 w-6 text-gray-500" />
            </div>
            <h3 className="text-lg font-medium mb-2">No withdrawal history</h3>
            <p className="text-muted-foreground max-w-md mx-auto">
              You haven't made any withdrawal requests yet. When you do, they will appear here.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
