"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ScalpBotLogo } from "@/components/scalp-bot-logo"
import { AlertCircle, CheckCircle, Eye, EyeOff } from "lucide-react"

export function RegisterForm({
  referralCode = "",
  onRegisterSuccess,
  onCancel,
}: {
  referralCode?: string
  onRegisterSuccess: (walletName: string) => void
  onCancel: () => void
}) {
  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState({
    walletName: "",
    email: "",
    password: "",
    confirmPassword: "",
  })
  const [showPassword, setShowPassword] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [registrationSuccess, setRegistrationSuccess] = useState(false)

  const validateStep1 = () => {
    const newErrors: Record<string, string> = {}

    if (!formData.walletName.trim()) {
      newErrors.walletName = "Wallet name is required"
    } else if (formData.walletName.length < 3) {
      newErrors.walletName = "Wallet name must be at least 3 characters"
    }

    if (!formData.email.trim()) {
      newErrors.email = "Email is required"
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "Email is invalid"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const validateStep2 = () => {
    const newErrors: Record<string, string> = {}

    if (!formData.password) {
      newErrors.password = "Password is required"
    } else if (formData.password.length < 8) {
      newErrors.password = "Password must be at least 8 characters"
    }

    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = "Passwords do not match"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleNext = () => {
    if (step === 1 && validateStep1()) {
      setStep(2)
    }
  }

  const handlePrevious = () => {
    setStep(1)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (validateStep2()) {
      setIsSubmitting(true)

      try {
        // In a real app, this would be an API call to register the user
        await new Promise((resolve) => setTimeout(resolve, 1500))

        setRegistrationSuccess(true)

        // Wait a moment to show success message before redirecting
        setTimeout(() => {
          onRegisterSuccess(formData.walletName)
        }, 1500)
      } catch (error) {
        setErrors({ submit: "Registration failed. Please try again." })
      } finally {
        setIsSubmitting(false)
      }
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-50 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1">
          <div className="flex justify-center mb-4">
            <ScalpBotLogo />
          </div>
          <CardTitle className="text-2xl font-bold text-center">Create an Account</CardTitle>
          <CardDescription className="text-center">
            {referralCode ? "You've been invited! " : ""}
            Enter your details to create your wallet.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {referralCode && (
            <Alert className="mb-4 bg-blue-50 border-blue-200">
              <AlertCircle className="h-4 w-4 text-blue-600" />
              <AlertDescription className="text-blue-700">
                You're signing up with a referral code. You'll be connected to your referrer's account.
              </AlertDescription>
            </Alert>
          )}

          {registrationSuccess ? (
            <div className="text-center py-6">
              <div className="bg-green-100 p-3 rounded-full inline-flex mb-4">
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-lg font-medium mb-2">Registration Successful!</h3>
              <p className="text-muted-foreground mb-4">
                Your wallet has been created successfully. You'll be redirected to your dashboard in a moment.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit}>
              {step === 1 ? (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="walletName">Wallet Name</Label>
                    <Input
                      id="walletName"
                      placeholder="Choose a unique wallet name"
                      value={formData.walletName}
                      onChange={(e) => setFormData({ ...formData, walletName: e.target.value })}
                    />
                    {errors.walletName && <p className="text-sm text-red-500">{errors.walletName}</p>}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="Enter your email address"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    />
                    {errors.email && <p className="text-sm text-red-500">{errors.email}</p>}
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="password">Password</Label>
                    <div className="relative">
                      <Input
                        id="password"
                        type={showPassword ? "text" : "password"}
                        placeholder="Create a secure password"
                        value={formData.password}
                        onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                        className="pr-10"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                        tabIndex={-1}
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                    {errors.password && <p className="text-sm text-red-500">{errors.password}</p>}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword">Confirm Password</Label>
                    <Input
                      id="confirmPassword"
                      type="password"
                      placeholder="Confirm your password"
                      value={formData.confirmPassword}
                      onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                    />
                    {errors.confirmPassword && <p className="text-sm text-red-500">{errors.confirmPassword}</p>}
                  </div>
                </div>
              )}

              {errors.submit && (
                <Alert variant="destructive" className="mt-4">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{errors.submit}</AlertDescription>
                </Alert>
              )}
            </form>
          )}
        </CardContent>
        <CardFooter>
          {!registrationSuccess && (
            <div className="flex w-full gap-2">
              {step === 1 ? (
                <>
                  <Button variant="outline" className="flex-1" onClick={onCancel}>
                    Cancel
                  </Button>
                  <Button className="flex-1" onClick={handleNext}>
                    Next
                  </Button>
                </>
              ) : (
                <>
                  <Button variant="outline" className="flex-1" onClick={handlePrevious}>
                    Back
                  </Button>
                  <Button className="flex-1" onClick={handleSubmit} disabled={isSubmitting}>
                    {isSubmitting ? "Creating..." : "Create Account"}
                  </Button>
                </>
              )}
            </div>
          )}
        </CardFooter>
      </Card>
    </div>
  )
}
