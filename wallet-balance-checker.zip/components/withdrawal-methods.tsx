"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Bitcoin, Wallet, CreditCard, DollarSign, AlertCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

const WITHDRAWAL_METHODS = [
  {
    id: "ton",
    name: "TON Network",
    icon: <Wallet className="h-5 w-5" />,
    placeholder: "Enter your TON wallet address",
    addressPrefix: "",
    minLength: 10,
  },
  {
    id: "btc",
    name: "Bitcoin",
    icon: <Bitcoin className="h-5 w-5" />,
    placeholder: "Enter your BTC wallet address",
    addressPrefix: "",
    minLength: 10,
  },
  {
    id: "eth",
    name: "Ethereum",
    icon: <CreditCard className="h-5 w-5" />,
    placeholder: "Enter your ETH wallet address",
    addressPrefix: "",
    minLength: 10,
  },
  {
    id: "usdt",
    name: "USDT (Tether)",
    icon: <DollarSign className="h-5 w-5" />,
    placeholder: "Enter your USDT wallet address",
    addressPrefix: "",
    minLength: 10,
  },
]

export function WithdrawalMethods({
  onSelect,
  onCancel,
}: {
  onSelect: (method: string, address: string) => void
  onCancel: () => void
}) {
  const [selectedMethod, setSelectedMethod] = useState("ton")
  const [address, setAddress] = useState("")
  const [error, setError] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const method = WITHDRAWAL_METHODS.find((m) => m.id === selectedMethod)

    if (!method) {
      setError("Please select a withdrawal method")
      return
    }

    if (!address) {
      setError("Please enter a wallet address")
      return
    }

    // Basic validation - just check minimum length
    if (address.length < 10) {
      setError("Address is too short. Please enter a valid address.")
      return
    }

    // Success - proceed with the address
    onSelect(selectedMethod, address)
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg max-w-md w-full">
      <h2 className="text-xl font-bold mb-4">Select Withdrawal Method</h2>

      {error && (
        <Alert variant="destructive" className="mb-4">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <form onSubmit={handleSubmit}>
        <div className="space-y-4">
          <RadioGroup value={selectedMethod} onValueChange={setSelectedMethod} className="gap-2">
            {WITHDRAWAL_METHODS.map((method) => (
              <div
                key={method.id}
                className={`flex items-center space-x-2 border rounded-md p-3 cursor-pointer transition-colors ${
                  selectedMethod === method.id ? "border-blue-500 bg-blue-50" : "border-gray-200 hover:bg-gray-50"
                }`}
                onClick={() => setSelectedMethod(method.id)}
              >
                <RadioGroupItem value={method.id} id={method.id} className="sr-only" />
                <div className="flex items-center flex-1">
                  <div className="mr-3 text-blue-600">{method.icon}</div>
                  <Label htmlFor={method.id} className="flex-1 cursor-pointer">
                    {method.name}
                  </Label>
                </div>
              </div>
            ))}
          </RadioGroup>

          <div className="space-y-2">
            <Label htmlFor="address">Wallet Address</Label>
            <Input
              id="address"
              value={address}
              onChange={(e) => {
                setAddress(e.target.value)
                setError("")
              }}
              placeholder={WITHDRAWAL_METHODS.find((m) => m.id === selectedMethod)?.placeholder}
            />
            <p className="text-xs text-muted-foreground">
              Double-check your address. We cannot recover funds sent to incorrect addresses.
            </p>
          </div>

          <div className="flex gap-3">
            <Button type="button" variant="outline" className="flex-1" onClick={onCancel}>
              Back
            </Button>
            <Button type="submit" className="flex-1">
              Continue
            </Button>
          </div>
        </div>
      </form>
    </div>
  )
}
