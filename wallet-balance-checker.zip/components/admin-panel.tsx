"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  AlertCircle,
  CheckCircle,
  ChevronDown,
  Clock,
  Eye,
  FileText,
  Search,
  Shield,
  User,
  XCircle,
  UserCheck,
} from "lucide-react"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"

// Mock verification requests - now only showing current session requests
const MOCK_VERIFICATION_REQUESTS = []

// Status badge component
function StatusBadge({ status }: { status: string }) {
  const variants = {
    pending: "bg-yellow-100 text-yellow-800 border-yellow-200",
    approved: "bg-green-100 text-green-800 border-green-200",
    rejected: "bg-red-100 text-red-800 border-red-200",
    verified: "bg-green-100 text-green-800 border-green-200",
    failed: "bg-red-100 text-red-800 border-red-200",
  }

  return (
    <Badge className={`${variants[status]} font-medium`} variant="outline">
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </Badge>
  )
}

export function AdminPanel({ onClose }: { onClose: () => void }) {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedRequest, setSelectedRequest] = useState<any>(null)
  const [viewDocumentDialog, setViewDocumentDialog] = useState(false)
  const [documentType, setDocumentType] = useState<"passport" | "address">("passport")
  const [verificationRequests, setVerificationRequests] = useState(MOCK_VERIFICATION_REQUESTS)
  const [verifyUserDialog, setVerifyUserDialog] = useState(false)
  const [userVerificationData, setUserVerificationData] = useState({
    walletName: "",
    fullName: "",
    dateOfBirth: "",
    address: "",
    notes: "",
  })

  // Filter requests based on search query
  const filteredRequests = verificationRequests.filter(
    (req) =>
      req.walletName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      req.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      req.id.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleViewDocument = (request: any, type: "passport" | "address") => {
    setSelectedRequest(request)
    setDocumentType(type)
    setViewDocumentDialog(true)
  }

  const handleUpdateStatus = (request: any, newStatus: string) => {
    // Update the status in the local state
    const updatedRequests = verificationRequests.map((req) => {
      if (req.id === request.id) {
        return { ...req, status: newStatus }
      }
      return req
    })
    setVerificationRequests(updatedRequests)

    // Show confirmation
    alert(`Request ${request.id} status updated to ${newStatus}`)
  }

  const handleOpenVerifyUser = () => {
    setUserVerificationData({
      walletName: "",
      fullName: "",
      dateOfBirth: "",
      address: "",
      notes: "",
    })
    setVerifyUserDialog(true)
  }

  const handleVerifyUser = () => {
    // Create a new verification record
    const newVerification = {
      id: `VR-${Math.floor(100000 + Math.random() * 900000)}`,
      walletName: userVerificationData.walletName,
      fullName: userVerificationData.fullName,
      dateOfBirth: userVerificationData.dateOfBirth,
      address: userVerificationData.address,
      notes: userVerificationData.notes,
      status: "verified",
      date: new Date().toISOString().split("T")[0],
      documents: {
        passport: true,
        address: true,
      },
      kyc: {
        status: "verified",
        level: 2,
      },
    }

    // Add to verification requests
    setVerificationRequests([newVerification, ...verificationRequests])
    setVerifyUserDialog(false)

    // Show confirmation
    alert(`User ${userVerificationData.walletName} has been verified successfully!`)
  }

  return (
    <div className="bg-white min-h-screen">
      <header className="border-b bg-white sticky top-0 z-10">
        <div className="container flex items-center justify-between h-16 px-4">
          <div className="flex items-center">
            <Shield className="h-6 w-6 text-blue-600 mr-2" />
            <h1 className="text-xl font-bold">Admin Verification Panel</h1>
          </div>
          <div className="flex items-center gap-2">
            <Button onClick={handleOpenVerifyUser} variant="outline" size="sm" className="mr-2">
              <UserCheck className="h-4 w-4 mr-2" />
              Verify User
            </Button>
            <Button onClick={onClose} variant="outline" size="sm">
              Exit Admin Panel
            </Button>
          </div>
        </div>
      </header>

      <main className="container px-4 py-6">
        <div className="flex flex-col md:flex-row gap-6">
          {/* Sidebar */}
          <div className="w-full md:w-64 space-y-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Verification Stats</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Pending</span>
                    <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-200">
                      {verificationRequests.filter((req) => req.status === "pending").length}
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Approved</span>
                    <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
                      {verificationRequests.filter((req) => req.status === "approved").length}
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Rejected</span>
                    <Badge variant="outline" className="bg-red-100 text-red-800 border-red-200">
                      {verificationRequests.filter((req) => req.status === "rejected").length}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Quick Filters</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button variant="outline" size="sm" className="w-full justify-start">
                  <Clock className="mr-2 h-4 w-4" />
                  Today's Requests
                </Button>
                <Button variant="outline" size="sm" className="w-full justify-start">
                  <AlertCircle className="mr-2 h-4 w-4" />
                  Pending Verification
                </Button>
                <Button variant="outline" size="sm" className="w-full justify-start">
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Approved Requests
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Main content */}
          <div className="flex-1">
            <Card>
              <CardHeader>
                <CardTitle>Verification Requests</CardTitle>
                <CardDescription>Manage and process user verification requests</CardDescription>
                <div className="relative mt-2">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search by wallet name, email or ID..."
                    className="pl-9"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="all">
                  <TabsList className="mb-4">
                    <TabsTrigger value="all">All Requests</TabsTrigger>
                    <TabsTrigger value="pending">Pending</TabsTrigger>
                    <TabsTrigger value="approved">Approved</TabsTrigger>
                    <TabsTrigger value="rejected">Rejected</TabsTrigger>
                  </TabsList>

                  <TabsContent value="all" className="m-0">
                    {filteredRequests.length > 0 ? (
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>ID</TableHead>
                            <TableHead>Wallet</TableHead>
                            <TableHead>Full Name</TableHead>
                            <TableHead>Date</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>KYC</TableHead>
                            <TableHead>Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {filteredRequests.map((request) => (
                            <TableRow key={request.id}>
                              <TableCell className="font-medium">{request.id}</TableCell>
                              <TableCell>
                                <div className="flex flex-col">
                                  <span>{request.walletName}</span>
                                  <span className="text-xs text-muted-foreground">{request.email}</span>
                                </div>
                              </TableCell>
                              <TableCell>{request.fullName || "N/A"}</TableCell>
                              <TableCell>{request.date}</TableCell>
                              <TableCell>
                                <StatusBadge status={request.status} />
                              </TableCell>
                              <TableCell>
                                <StatusBadge status={request.kyc.status} />
                              </TableCell>
                              <TableCell>
                                <DropdownMenu>
                                  <DropdownMenuTrigger asChild>
                                    <Button variant="ghost" size="sm">
                                      Actions <ChevronDown className="ml-2 h-4 w-4" />
                                    </Button>
                                  </DropdownMenuTrigger>
                                  <DropdownMenuContent align="end">
                                    <DropdownMenuLabel>Documents</DropdownMenuLabel>
                                    <DropdownMenuItem onClick={() => handleViewDocument(request, "passport")}>
                                      <User className="mr-2 h-4 w-4" />
                                      View Passport
                                    </DropdownMenuItem>
                                    <DropdownMenuItem onClick={() => handleViewDocument(request, "address")}>
                                      <FileText className="mr-2 h-4 w-4" />
                                      View Address Proof
                                    </DropdownMenuItem>
                                    <DropdownMenuSeparator />
                                    <DropdownMenuLabel>Update Status</DropdownMenuLabel>
                                    <DropdownMenuItem onClick={() => handleUpdateStatus(request, "approved")}>
                                      <CheckCircle className="mr-2 h-4 w-4 text-green-600" />
                                      Approve Request
                                    </DropdownMenuItem>
                                    <DropdownMenuItem onClick={() => handleUpdateStatus(request, "rejected")}>
                                      <XCircle className="mr-2 h-4 w-4 text-red-600" />
                                      Reject Request
                                    </DropdownMenuItem>
                                  </DropdownMenuContent>
                                </DropdownMenu>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    ) : (
                      <div className="py-8 text-center">
                        <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-gray-100 mb-4">
                          <FileText className="h-6 w-6 text-gray-500" />
                        </div>
                        <h3 className="text-lg font-medium mb-2">No verification requests</h3>
                        <p className="text-muted-foreground max-w-md mx-auto">
                          There are currently no verification requests to review. New requests will appear here when
                          users submit withdrawal requests.
                        </p>
                      </div>
                    )}
                  </TabsContent>

                  {/* Other tabs would filter by status */}
                  <TabsContent value="pending" className="m-0">
                    <Table>{/* Similar structure as "all" tab but filtered */}</Table>
                  </TabsContent>
                </Tabs>
              </CardContent>
              <CardFooter className="flex justify-between">
                <div className="text-sm text-muted-foreground">
                  Showing {filteredRequests.length} of {verificationRequests.length} requests
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" disabled>
                    Previous
                  </Button>
                  <Button variant="outline" size="sm" disabled>
                    Next
                  </Button>
                </div>
              </CardFooter>
            </Card>
          </div>
        </div>
      </main>

      {/* Document Viewer Dialog */}
      <Dialog open={viewDocumentDialog} onOpenChange={setViewDocumentDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{documentType === "passport" ? "Passport Document" : "Proof of Address"}</DialogTitle>
            <DialogDescription>
              Viewing document for {selectedRequest?.walletName} ({selectedRequest?.id})
            </DialogDescription>
          </DialogHeader>

          <div className="border rounded-md p-4 flex flex-col items-center justify-center min-h-[300px]">
            <Eye className="h-16 w-16 text-muted-foreground mb-4" />
            <p className="text-center text-muted-foreground">
              {selectedRequest?.documents[documentType]
                ? "Document is available and can be viewed in the actual system."
                : "Document not provided or unavailable."}
            </p>
            {!selectedRequest?.documents[documentType] && (
              <Badge variant="destructive" className="mt-2">
                Missing Document
              </Badge>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setViewDocumentDialog(false)}>
              Close
            </Button>
            {selectedRequest?.documents[documentType] && <Button>Download Document</Button>}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Verify User Dialog */}
      <Dialog open={verifyUserDialog} onOpenChange={setVerifyUserDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Verify User</DialogTitle>
            <DialogDescription>
              Manually verify a user by entering their information and uploading documents.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="walletName">Wallet Name</Label>
              <Input
                id="walletName"
                value={userVerificationData.walletName}
                onChange={(e) => setUserVerificationData({ ...userVerificationData, walletName: e.target.value })}
                placeholder="Enter wallet name"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="fullName">Full Name</Label>
              <Input
                id="fullName"
                value={userVerificationData.fullName}
                onChange={(e) => setUserVerificationData({ ...userVerificationData, fullName: e.target.value })}
                placeholder="Enter user's full name"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="dateOfBirth">Date of Birth</Label>
              <Input
                id="dateOfBirth"
                type="date"
                value={userVerificationData.dateOfBirth}
                onChange={(e) => setUserVerificationData({ ...userVerificationData, dateOfBirth: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="address">Address</Label>
              <Textarea
                id="address"
                value={userVerificationData.address}
                onChange={(e) => setUserVerificationData({ ...userVerificationData, address: e.target.value })}
                placeholder="Enter user's address"
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                value={userVerificationData.notes}
                onChange={(e) => setUserVerificationData({ ...userVerificationData, notes: e.target.value })}
                placeholder="Additional notes (optional)"
                rows={2}
              />
            </div>

            <div className="space-y-2">
              <Label>Documents</Label>
              <div className="grid grid-cols-2 gap-4">
                <div className="border-2 border-dashed rounded-md p-4 flex flex-col items-center justify-center">
                  <FileText className="h-8 w-8 text-muted-foreground mb-2" />
                  <p className="text-xs text-center text-muted-foreground">Upload Passport/ID</p>
                  <Button variant="outline" size="sm" className="mt-2">
                    Upload
                  </Button>
                </div>
                <div className="border-2 border-dashed rounded-md p-4 flex flex-col items-center justify-center">
                  <FileText className="h-8 w-8 text-muted-foreground mb-2" />
                  <p className="text-xs text-center text-muted-foreground">Upload Address Proof</p>
                  <Button variant="outline" size="sm" className="mt-2">
                    Upload
                  </Button>
                </div>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setVerifyUserDialog(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleVerifyUser}
              disabled={!userVerificationData.walletName || !userVerificationData.fullName}
            >
              Verify User
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
